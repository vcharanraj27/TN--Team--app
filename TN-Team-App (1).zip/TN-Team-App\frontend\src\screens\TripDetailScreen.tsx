import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { api } from '../api';
import { Trip, Location } from '../types';
import { TripMap } from '../components/TripMap';
import { LoadingSpinner, ErrorBanner } from '../components/States';
import { formatFullDate, formatTime, formatDistance, formatDuration } from '../utils';
import {
  ArrowLeft,
  MapPin,
  Clock,
  Navigation2,
  Trash2,
  Gauge,
  Calendar,
  AlertTriangle,
} from 'lucide-react';

export function TripDetailScreen() {
  const { id } = useParams<{ id: string }>();
  const { token } = useAuth();
  const navigate = useNavigate();
  const [trip, setTrip] = useState<Trip | null>(null);
  const [locations, setLocations] = useState<Location[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [deleting, setDeleting] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);

  useEffect(() => {
    if (!token || !id) return;
    Promise.all([
      api.trips.get(token, id),
      api.trips.locations(token, id),
    ])
      .then(([t, locs]) => { setTrip(t); setLocations(locs); })
      .catch(e => setError(e.message))
      .finally(() => setLoading(false));
  }, [token, id]);

  const handleDelete = async () => {
    if (!token || !id) return;
    setDeleting(true);
    try {
      await api.trips.delete(token, id);
      navigate(-1);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to delete trip');
      setDeleting(false);
    }
  };

  const avgSpeedKmh = trip && trip.duration_s > 0
    ? Math.round((trip.distance_m / 1000) / (trip.duration_s / 3600))
    : 0;

  if (loading) return <LoadingSpinner fullScreen message="Loading route analysis..." />;

  return (
    <div className="h-full flex flex-col bg-slate-50">
      {/* TOP BAR */}
      <div className="bg-white/95 backdrop-blur-md px-4 pt-12 pb-3.5 border-b border-slate-200/80 sticky top-0 z-20 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate(-1)}
            className="p-2 rounded-2xl bg-slate-100 hover:bg-slate-200 active:scale-95 transition-all"
          >
            <ArrowLeft className="w-5 h-5 text-slate-700" />
          </button>
          <div>
            <h1 className="text-base font-black text-slate-900 tracking-tight">Route Details</h1>
            {trip && (
              <p className="text-xs text-slate-500 font-medium flex items-center gap-1">
                <Calendar className="w-3 h-3" /> {formatFullDate(trip.started_at)}
              </p>
            )}
          </div>
        </div>

        <button
          onClick={() => setConfirmDelete(true)}
          className="p-2 rounded-2xl text-red-600 hover:bg-red-50 active:scale-95 transition-all"
          title="Delete Trip"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>

      {error && <ErrorBanner message={error} />}

      {trip && (
        <div className="flex-1 overflow-y-auto pb-12">
          {/* ROUTE MAP */}
          <div className="relative border-b border-slate-200 shadow-inner">
            <TripMap locations={locations} className="h-72" />
            <div className="absolute bottom-3 left-3 glass-card px-3 py-1.5 rounded-2xl shadow-md text-[11px] font-bold text-slate-700 flex items-center gap-1.5 z-10">
              <span className="w-2 h-2 rounded-full bg-blue-600" />
              {locations.length} GPS Waypoints
            </div>
          </div>

          {/* TELEMETRY TILES */}
          <div className="px-4 mt-4 grid grid-cols-3 gap-2.5">
            <div className="bg-white border border-slate-100 rounded-3xl p-3 text-center shadow-sm">
              <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-1 flex items-center justify-center gap-1">
                <Navigation2 className="w-3 h-3 text-blue-500" /> Distance
              </p>
              <p className="text-xl font-black text-blue-600 font-mono">{formatDistance(trip.distance_m)}</p>
            </div>
            <div className="bg-white border border-slate-100 rounded-3xl p-3 text-center shadow-sm">
              <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-1 flex items-center justify-center gap-1">
                <Clock className="w-3 h-3 text-slate-500" /> Duration
              </p>
              <p className="text-xl font-black text-slate-900 font-mono">{formatDuration(trip.duration_s)}</p>
            </div>
            <div className="bg-white border border-slate-100 rounded-3xl p-3 text-center shadow-sm">
              <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-1 flex items-center justify-center gap-1">
                <Gauge className="w-3 h-3 text-purple-500" /> Avg Speed
              </p>
              <p className="text-xl font-black text-slate-900 font-mono">{avgSpeedKmh} <span className="text-[10px] font-normal text-slate-400">km/h</span></p>
            </div>
          </div>

          {/* ROUTE WAYPOINT CARD */}
          <div className="mx-4 mt-4 bg-white border border-slate-100 rounded-3xl p-4 shadow-sm">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3.5">
              Trip Journey
            </h3>

            <div className="space-y-4">
              {/* Origin */}
              <div className="flex gap-3">
                <div className="flex flex-col items-center">
                  <span className="w-3.5 h-3.5 bg-green-500 rounded-full border-2 border-white shadow-md ring-2 ring-green-100" />
                  <span className="w-0.5 h-10 bg-slate-200 my-1" />
                </div>
                <div className="flex-1 pb-2">
                  <span className="text-[10px] font-bold text-green-700 bg-green-50 px-2 py-0.5 rounded-lg uppercase tracking-wider">
                    Start Location
                  </span>
                  <p className="text-sm font-bold text-slate-900 mt-1">{trip.start_address || 'Origin coordinate'}</p>
                  <p className="text-xs text-slate-400 mt-0.5 font-mono">{formatTime(trip.started_at)}</p>
                </div>
              </div>

              {/* Destination */}
              <div className="flex gap-3">
                <div className="flex flex-col items-center">
                  <span className="w-3.5 h-3.5 bg-red-500 rounded-full border-2 border-white shadow-md ring-2 ring-red-100" />
                </div>
                <div className="flex-1">
                  <span className="text-[10px] font-bold text-red-700 bg-red-50 px-2 py-0.5 rounded-lg uppercase tracking-wider">
                    End Location
                  </span>
                  <p className="text-sm font-bold text-slate-900 mt-1">{trip.end_address || 'Destination coordinate'}</p>
                  <p className="text-xs text-slate-400 mt-0.5 font-mono">
                    {trip.ended_at ? formatTime(trip.ended_at) : 'Trip completed'}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* DELETE CONFIRMATION MODAL */}
          {confirmDelete && (
            <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm flex items-end sm:items-center justify-center p-4 z-50">
              <div className="w-full max-w-sm bg-white rounded-3xl p-6 shadow-2xl slide-up">
                <div className="w-12 h-12 bg-red-100 rounded-2xl flex items-center justify-center mx-auto mb-3">
                  <AlertTriangle className="w-6 h-6 text-red-600" />
                </div>
                <h3 className="text-lg font-bold text-slate-900 text-center mb-1">Delete Trip Record?</h3>
                <p className="text-xs text-slate-500 text-center mb-5 leading-relaxed">
                  This will permanently delete this trip and its {locations.length} recorded GPS coordinates from the database.
                </p>
                <div className="flex gap-2.5">
                  <button
                    onClick={() => setConfirmDelete(false)}
                    className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-2xl text-xs font-bold transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleDelete}
                    disabled={deleting}
                    className="flex-1 py-3 bg-red-600 hover:bg-red-700 text-white rounded-2xl text-xs font-bold shadow-lg shadow-red-600/30 transition-colors"
                  >
                    {deleting ? 'Deleting...' : 'Yes, Delete'}
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
