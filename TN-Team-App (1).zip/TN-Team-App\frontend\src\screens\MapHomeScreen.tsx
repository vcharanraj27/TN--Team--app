import { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { api } from '../api';
import { Location } from '../types';
import { LiveMap } from '../components/LiveMap';
import { formatDistance, formatDuration } from '../utils';
import {
  Play,
  Pause,
  Square,
  MapPin,
  Navigation,
  AlertCircle,
  Compass,
  Gauge,
  Crosshair,
  Sparkles,
  ShieldCheck,
  Users,
  Navigation2,
} from 'lucide-react';

type PermState = 'unknown' | 'requesting' | 'granted' | 'denied';

interface TrackingState {
  isTracking: boolean;
  isPaused: boolean;
  tripId: string | null;
  startTime: number | null;
  distance: number;
  elapsed: number;
  routeLocations: Location[];
  prevLat?: number;
  prevLng?: number;
}

export function MapHomeScreen() {
  const { user, token } = useAuth();
  const navigate = useNavigate();
  const [permState, setPermState] = useState<PermState>('unknown');
  const [currentLat, setCurrentLat] = useState<number | undefined>();
  const [currentLng, setCurrentLng] = useState<number | undefined>();
  const [speedKmh, setSpeedKmh] = useState<number>(0);
  const [accuracyM, setAccuracyM] = useState<number | null>(null);

  const [tracking, setTracking] = useState<TrackingState>({
    isTracking: false,
    isPaused: false,
    tripId: null,
    startTime: null,
    distance: 0,
    elapsed: 0,
    routeLocations: [],
  });

  const [error, setError] = useState('');
  const [isSimulating, setIsSimulating] = useState(false);
  const watchId = useRef<number | null>(null);
  const simTimer = useRef<ReturnType<typeof setInterval> | null>(null);
  const tickRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const trackingRef = useRef(tracking);
  trackingRef.current = tracking;

  // Real GPS watch position
  const startLocationWatch = useCallback(() => {
    if (!navigator.geolocation) {
      setPermState('denied');
      setError('Geolocation is not supported on this browser');
      return;
    }
    setPermState('requesting');

    watchId.current = navigator.geolocation.watchPosition(
      (pos) => {
        setPermState('granted');
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        setCurrentLat(lat);
        setCurrentLng(lng);
        setSpeedKmh(pos.coords.speed ? Math.round(pos.coords.speed * 3.6) : 0);
        setAccuracyM(pos.coords.accuracy ? Math.round(pos.coords.accuracy) : null);

        const t = trackingRef.current;
        if (t.isTracking && !t.isPaused && t.tripId && token) {
          let dist = t.distance;
          if (t.prevLat !== undefined && t.prevLng !== undefined) {
            const R = 6371000;
            const φ1 = (t.prevLat * Math.PI) / 180;
            const φ2 = (lat * Math.PI) / 180;
            const Δφ = ((lat - t.prevLat) * Math.PI) / 180;
            const Δλ = ((lng - t.prevLng) * Math.PI) / 180;
            const a = Math.sin(Δφ / 2) ** 2 + Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) ** 2;
            dist += R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
          }

          const newLoc: Location = {
            id: Date.now().toString(),
            lat,
            lng,
            accuracy: pos.coords.accuracy,
            speed: pos.coords.speed,
            heading: pos.coords.heading,
            altitude: pos.coords.altitude,
            timestamp: new Date().toISOString(),
          };

          setTracking(prev => ({
            ...prev,
            distance: dist,
            prevLat: lat,
            prevLng: lng,
            routeLocations: [...prev.routeLocations, newLoc],
          }));

          api.locations.post(token, {
            lat,
            lng,
            accuracy: pos.coords.accuracy,
            speed: pos.coords.speed,
            tripId: t.tripId,
            isTracking: true,
          }).catch(console.error);
        }
      },
      (err) => {
        if (err.code === err.PERMISSION_DENIED) {
          setPermState('denied');
        }
        // Fallback default coordinates if GPS not active on PC
        if (currentLat === undefined) {
          setCurrentLat(51.505);
          setCurrentLng(-0.09);
        }
      },
      { enableHighAccuracy: true, maximumAge: 3000, timeout: 10000 }
    );
  }, [token, currentLat]);

  // Demo simulator for testing GPS movement on phone or desktop
  const toggleSimulation = () => {
    if (isSimulating) {
      if (simTimer.current) clearInterval(simTimer.current);
      setIsSimulating(false);
      return;
    }

    setIsSimulating(true);
    let lat = currentLat || 51.505;
    let lng = currentLng || -0.09;
    setPermState('granted');
    setCurrentLat(lat);
    setCurrentLng(lng);

    simTimer.current = setInterval(() => {
      lat += (Math.random() - 0.48) * 0.0008;
      lng += (Math.random() - 0.48) * 0.0008;
      setCurrentLat(lat);
      setCurrentLng(lng);
      setSpeedKmh(Math.floor(20 + Math.random() * 25));
      setAccuracyM(5);

      const t = trackingRef.current;
      if (t.isTracking && !t.isPaused && t.tripId && token) {
        let dist = t.distance;
        if (t.prevLat !== undefined && t.prevLng !== undefined) {
          const R = 6371000;
          const φ1 = (t.prevLat * Math.PI) / 180;
          const φ2 = (lat * Math.PI) / 180;
          const Δφ = ((lat - t.prevLat) * Math.PI) / 180;
          const Δλ = ((lng - t.prevLng) * Math.PI) / 180;
          const a = Math.sin(Δφ / 2) ** 2 + Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) ** 2;
          dist += R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        }

        const newLoc: Location = {
          id: Date.now().toString(),
          lat,
          lng,
          accuracy: 5,
          speed: 8.5,
          heading: 90,
          altitude: 20,
          timestamp: new Date().toISOString(),
        };

        setTracking(prev => ({
          ...prev,
          distance: dist,
          prevLat: lat,
          prevLng: lng,
          routeLocations: [...prev.routeLocations, newLoc],
        }));

        api.locations.post(token, {
          lat,
          lng,
          accuracy: 5,
          speed: 8.5,
          tripId: t.tripId,
          isTracking: true,
        }).catch(console.error);
      }
    }, 2000);
  };

  useEffect(() => {
    return () => {
      if (watchId.current !== null) navigator.geolocation.clearWatch(watchId.current);
      if (simTimer.current) clearInterval(simTimer.current);
    };
  }, []);

  // Timer tick for active trip
  useEffect(() => {
    if (tracking.isTracking && !tracking.isPaused && tracking.startTime) {
      tickRef.current = setInterval(() => {
        setTracking(prev => ({
          ...prev,
          elapsed: Math.floor((Date.now() - (prev.startTime ?? Date.now())) / 1000),
        }));
      }, 1000);
    } else {
      if (tickRef.current) clearInterval(tickRef.current);
    }
    return () => { if (tickRef.current) clearInterval(tickRef.current); };
  }, [tracking.isTracking, tracking.isPaused]);

  const handleStartTracking = async () => {
    if (!token) return;
    setError('');
    try {
      const trip = await api.trips.start(token, {
        startLat: currentLat,
        startLng: currentLng,
        startAddress: 'Trip origin point',
      });
      setTracking({
        isTracking: true,
        isPaused: false,
        tripId: trip.id,
        startTime: Date.now(),
        distance: 0,
        elapsed: 0,
        routeLocations: currentLat && currentLng ? [{
          id: Date.now().toString(),
          lat: currentLat,
          lng: currentLng,
          accuracy: accuracyM,
          speed: 0,
          heading: 0,
          altitude: null,
          timestamp: new Date().toISOString(),
        }] : [],
        prevLat: currentLat,
        prevLng: currentLng,
      });
      if (!watchId.current && !isSimulating) startLocationWatch();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to start trip');
    }
  };

  const handlePauseResume = async () => {
    if (!token || !tracking.tripId) return;
    try {
      const action = tracking.isPaused ? 'resume' : 'pause';
      await api.trips.update(token, tracking.tripId, { action });
      setTracking(prev => ({
        ...prev,
        isPaused: !prev.isPaused,
        startTime: prev.isPaused ? Date.now() - prev.elapsed * 1000 : prev.startTime,
      }));
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to update trip');
    }
  };

  const handleStop = async () => {
    if (!token || !tracking.tripId) return;
    try {
      await api.trips.update(token, tracking.tripId, {
        action: 'stop',
        endLat: currentLat,
        endLng: currentLng,
        endAddress: 'Trip destination',
        distanceM: Math.round(tracking.distance),
        durationS: tracking.elapsed,
      });
      setTracking({
        isTracking: false,
        isPaused: false,
        tripId: null,
        startTime: null,
        distance: 0,
        elapsed: 0,
        routeLocations: [],
      });
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to stop trip');
    }
  };

  return (
    <div className="h-full flex flex-col relative bg-slate-900">
      {/* MAP VIEW */}
      <div className="flex-1 relative overflow-hidden">
        <LiveMap
          currentLat={currentLat}
          currentLng={currentLng}
          routeLocations={tracking.routeLocations}
          isTracking={tracking.isTracking}
          isPaused={tracking.isPaused}
          className="absolute inset-0"
        />

        {/* TOP STATUS BAR OVERLAY */}
        <div className="absolute top-0 left-0 right-0 p-3 pt-safe z-20 pointer-events-none">
          <div className="flex flex-col gap-2 pointer-events-auto">
            <div className="flex items-center justify-between">
              {/* User & Team Tag */}
              <div className="glass-card px-3.5 py-2 rounded-2xl shadow-lg flex items-center gap-2.5">
                <div className="relative">
                  <div
                    className="w-7 h-7 rounded-full flex items-center justify-center font-bold text-white text-xs shadow-inner"
                    style={{ backgroundColor: user?.avatarColor || '#3b82f6' }}
                  >
                    {user?.name.slice(0, 1)}
                  </div>
                  {tracking.isTracking && !tracking.isPaused && (
                    <div className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 bg-green-500 rounded-full tracking-pulse border border-white" />
                  )}
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-900 leading-tight truncate max-w-[120px]">{user?.name}</p>
                  <p className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider">{user?.teamName}</p>
                </div>
              </div>

              {/* GPS Signal & Status Chip */}
              <div className="flex items-center gap-2">
                <button
                  onClick={toggleSimulation}
                  className={`glass-card px-2.5 py-1.5 rounded-2xl text-[11px] font-bold shadow-md flex items-center gap-1 transition-colors ${
                    isSimulating ? 'bg-amber-500 text-white border-amber-400' : 'text-slate-700 hover:bg-white'
                  }`}
                  title="Toggle GPS Simulation"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  {isSimulating ? 'Simulating' : 'Simulate'}
                </button>

                {tracking.isTracking && (
                  <div className={`px-3 py-1.5 rounded-2xl text-xs font-bold text-white shadow-lg flex items-center gap-1.5 ${
                    tracking.isPaused ? 'bg-amber-500' : 'bg-green-600 tracking-pulse'
                  }`}>
                    <span className="w-1.5 h-1.5 bg-white rounded-full" />
                    {tracking.isPaused ? 'PAUSED' : 'LIVE'}
                  </div>
                )}
              </div>
            </div>

            {/* If Manager: Show Quick Switcher between Team Radar & My GPS Trip */}
            {user?.role === 'manager' && (
              <div className="flex bg-slate-900/80 backdrop-blur-md p-1 rounded-2xl border border-white/20 shadow-xl">
                <button
                  onClick={() => navigate('/')}
                  className="flex-1 py-1.5 rounded-xl text-xs font-bold text-slate-300 hover:text-white transition-all flex items-center justify-center gap-1.5"
                >
                  <Users className="w-3.5 h-3.5 text-purple-400" />
                  Team Radar
                </button>
                <button
                  className="flex-1 py-1.5 rounded-xl text-xs font-bold bg-white text-blue-700 shadow-sm flex items-center justify-center gap-1.5"
                >
                  <Navigation2 className="w-3.5 h-3.5 text-blue-600" />
                  My Live GPS Trip
                </button>
              </div>
            )}
          </div>
        </div>

        {/* FLOATING ACTION BUTTONS */}
        <div className="absolute right-3 bottom-36 z-20 flex flex-col gap-2">
          <button
            onClick={() => {
              if (currentLat && currentLng) {
                // Trigger watch refresh or center
                startLocationWatch();
              }
            }}
            className="w-11 h-11 glass-card rounded-2xl shadow-lg flex items-center justify-center text-slate-700 active:scale-90 transition-transform"
            title="Recenter Map"
          >
            <Crosshair className="w-5 h-5 text-blue-600" />
          </button>
        </div>

        {/* PERMISSION MODAL SHEET */}
        {permState === 'unknown' && (
          <div className="absolute inset-0 bg-slate-950/70 backdrop-blur-sm flex items-end z-30">
            <div className="w-full bg-white rounded-t-[32px] p-6 slide-up shadow-2xl">
              <div className="w-12 h-1 bg-slate-200 rounded-full mx-auto mb-5" />
              <div className="w-14 h-14 bg-blue-100 rounded-3xl flex items-center justify-center mx-auto mb-3 shadow-inner">
                <Navigation className="w-7 h-7 text-blue-600" />
              </div>
              <h2 className="text-lg font-bold text-slate-900 text-center mb-1.5">Enable Location Tracking</h2>
              <p className="text-xs text-slate-600 text-center leading-relaxed mb-5 max-w-xs mx-auto">
                TN Team captures your GPS coordinates while a trip is active to calculate your routes, mileage, and drive duration.
              </p>
              <div className="flex items-center gap-2 text-[11px] text-slate-500 bg-slate-50 p-2.5 rounded-2xl mb-4">
                <ShieldCheck className="w-4 h-4 text-green-600 shrink-0" />
                <span>Protected by database RBAC. Location is only shared during active trips.</span>
              </div>
              <button
                onClick={startLocationWatch}
                className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-2xl text-sm shadow-lg shadow-blue-600/30 transition-all active:scale-95"
              >
                Allow GPS &amp; Start
              </button>
            </div>
          </div>
        )}

        {permState === 'denied' && (
          <div className="absolute top-16 left-4 right-4 z-20">
            <div className="glass-card bg-amber-50/95 border-amber-200 rounded-2xl p-3.5 shadow-lg flex items-start gap-2.5">
              <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div className="text-xs">
                <p className="font-bold text-amber-900">Location permission required</p>
                <p className="text-amber-700 mt-0.5">Please allow location in your browser settings or tap "Simulate" to preview.</p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* BOTTOM TELEMETRY & CONTROLS DRAWER */}
      <div className="glass-card rounded-t-[32px] px-5 pt-4 pb-20 shadow-2xl border-t border-white/60 z-30">
        <div className="w-10 h-1 bg-slate-200 rounded-full mx-auto mb-3.5" />

        {error && (
          <div className="mb-3 p-2.5 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 font-semibold">
            {error}
          </div>
        )}

        {tracking.isTracking ? (
          <div>
            {/* LIVE TELEMETRY TILES */}
            <div className="grid grid-cols-3 gap-2.5 mb-4">
              <div className="bg-slate-50 border border-slate-100 rounded-2xl p-2.5 text-center shadow-sm">
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-0.5">Duration</p>
                <p className="text-xl font-black text-slate-900 font-mono">{formatDuration(tracking.elapsed)}</p>
              </div>
              <div className="bg-slate-50 border border-slate-100 rounded-2xl p-2.5 text-center shadow-sm">
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-0.5">Distance</p>
                <p className="text-xl font-black text-blue-600 font-mono">{formatDistance(tracking.distance)}</p>
              </div>
              <div className="bg-slate-50 border border-slate-100 rounded-2xl p-2.5 text-center shadow-sm">
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-0.5">Speed</p>
                <p className="text-xl font-black text-slate-900 font-mono">{speedKmh} <span className="text-[10px] font-normal text-slate-500">km/h</span></p>
              </div>
            </div>

            {/* CONTROLS */}
            <div className="flex gap-2.5">
              <button
                onClick={handlePauseResume}
                className={`flex-1 py-3.5 rounded-2xl font-bold text-sm shadow-md flex items-center justify-center gap-2 active:scale-95 transition-all ${
                  tracking.isPaused
                    ? 'bg-green-600 hover:bg-green-700 text-white shadow-green-600/30'
                    : 'bg-amber-100 hover:bg-amber-200 text-amber-800'
                }`}
              >
                {tracking.isPaused ? <Play className="w-4 h-4 fill-current" /> : <Pause className="w-4 h-4 fill-current" />}
                {tracking.isPaused ? 'Resume Trip' : 'Pause Trip'}
              </button>
              <button
                onClick={handleStop}
                className="flex-1 py-3.5 bg-red-600 hover:bg-red-700 text-white rounded-2xl font-bold text-sm shadow-md shadow-red-600/30 flex items-center justify-center gap-2 active:scale-95 transition-all"
              >
                <Square className="w-4 h-4 fill-current" />
                Finish Trip
              </button>
            </div>
          </div>
        ) : (
          <div>
            {/* GPS STATUS METRICS */}
            <div className="flex items-center justify-between text-xs text-slate-500 px-1 mb-3">
              <span className="flex items-center gap-1.5 font-medium">
                <span className={`w-2 h-2 rounded-full ${currentLat ? 'bg-green-500' : 'bg-amber-400 animate-ping'}`} />
                {currentLat ? 'GPS Ready' : 'Acquiring GPS Fix...'}
              </span>
              {accuracyM !== null && (
                <span className="text-[11px] font-semibold text-slate-400">
                  Accuracy: ±{accuracyM}m
                </span>
              )}
            </div>

            {/* START BUTTON */}
            <button
              onClick={handleStartTracking}
              className="w-full py-4 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-bold rounded-2xl text-base shadow-xl shadow-blue-600/30 flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
            >
              <Navigation className="w-5 h-5 fill-current" />
              Start New Trip
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
