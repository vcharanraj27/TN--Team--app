import { useLocation, useNavigate } from 'react-router-dom';

export function useNavigation() {
  const location = useLocation();
  const navigate = useNavigate();
  return {
    navigate,
    currentPath: location.pathname,
  };
}
