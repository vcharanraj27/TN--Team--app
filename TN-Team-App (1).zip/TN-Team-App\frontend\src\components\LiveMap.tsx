import { useEffect, useRef, useCallback } from 'react';
import L from 'leaflet';
import { Location } from '../types';

interface LiveMapProps {
  currentLat?: number;
  currentLng?: number;
  routeLocations?: Location[];
  isTracking: boolean;
  isPaused: boolean;
  className?: string;
}

export function LiveMap({ currentLat, currentLng, routeLocations = [], isTracking, isPaused, className = '' }: LiveMapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const leafletMap = useRef<L.Map | null>(null);
  const myMarker = useRef<L.Marker | null>(null);
  const routeLine = useRef<L.Polyline | null>(null);
  const accuracyCircle = useRef<L.Circle | null>(null);

  const getMyMarkerIcon = useCallback((tracking: boolean, paused: boolean) => {
    const color = paused ? '#f59e0b' : tracking ? '#22c55e' : '#2563eb';
    const pulse = tracking && !paused;
    return L.divIcon({
      className: '',
      html: `
        <div style="position:relative;display:flex;align-items:center;justify-content:center;">
          ${pulse ? `<div style="position:absolute;width:36px;height:36px;border-radius:50%;background:${color}33;animation:ping 1.5s cubic-bezier(0,0,0.2,1) infinite;"></div>` : ''}
          <div style="width:18px;height:18px;background:${color};border-radius:50%;border:3px solid white;box-shadow:0 2px 8px rgba(0,0,0,0.3);position:relative;z-index:1;"></div>
        </div>
      `,
      iconAnchor: [9, 9],
    });
  }, []);

  useEffect(() => {
    if (!mapRef.current) return;
    const map = L.map(mapRef.current, { zoomControl: false, attributionControl: false });
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19 }).addTo(map);
    L.control.zoom({ position: 'bottomright' }).addTo(map);
    map.setView([51.505, -0.09], 14);
    leafletMap.current = map;

    return () => {
      map.remove();
      leafletMap.current = null;
    };
  }, []);

  // Update my position
  useEffect(() => {
    const map = leafletMap.current;
    if (!map || currentLat === undefined || currentLng === undefined) return;

    const pos: [number, number] = [currentLat, currentLng];

    if (!myMarker.current) {
      myMarker.current = L.marker(pos, { icon: getMyMarkerIcon(isTracking, isPaused), zIndexOffset: 1000 }).addTo(map);
      map.setView(pos, 15, { animate: true });
    } else {
      myMarker.current.setLatLng(pos);
      myMarker.current.setIcon(getMyMarkerIcon(isTracking, isPaused));
    }
  }, [currentLat, currentLng, isTracking, isPaused, getMyMarkerIcon]);

  // Update route
  useEffect(() => {
    const map = leafletMap.current;
    if (!map) return;

    if (routeLine.current) {
      map.removeLayer(routeLine.current);
      routeLine.current = null;
    }

    if (routeLocations.length > 1) {
      const coords = routeLocations.map(l => [l.lat, l.lng] as [number, number]);
      routeLine.current = L.polyline(coords, {
        color: isPaused ? '#f59e0b' : '#2563eb',
        weight: 5,
        opacity: 0.9,
        lineCap: 'round',
        dashArray: isPaused ? '8 6' : undefined,
      }).addTo(map);
    }
  }, [routeLocations, isPaused]);

  return <div ref={mapRef} className={`w-full h-full ${className}`} />;
}
