import express from 'express';
import cors from 'cors';
import compression from 'compression';
import path from 'path';
import fs from 'fs';
import { config } from './config';
import { initDb, closeDb, backupDb, persistDb } from './database';
import { authRouter } from './routes/auth';
import { tripsRouter } from './routes/trips';
import { locationsRouter } from './routes/locations';
import { managerRouter } from './routes/manager';
import { dailyRouter } from './routes/daily';

const app = express();

// Allow all origins for tunnel / mobile phone access
app.use(cors({ origin: true, credentials: true }));
app.use(compression());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// API Routes
app.use('/api/auth', authRouter);
app.use('/api/trips', tripsRouter);
app.use('/api/locations', locationsRouter);
app.use('/api/manager', managerRouter);
app.use('/api/daily', dailyRouter);

// Health check
app.get('/api/health', (_, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Direct zip download endpoint
app.get('/api/download/zip', (_req, res) => {
  const zipPath = path.resolve(__dirname, '../../../TN-Team-App.zip');
  const fallbackPath = path.resolve(__dirname, '../../../teamtrack-gps-app.zip');
  if (fs.existsSync(zipPath)) {
    res.download(zipPath, 'TN-Team-App.zip');
  } else if (fs.existsSync(fallbackPath)) {
    res.download(fallbackPath, 'TN-Team-App.zip');
  } else {
    res.status(404).json({ error: 'Zip file not generated yet' });
  }
});

// Database backup download endpoint
app.get('/api/backup', (_req, res) => {
  const backupFile = backupDb('manual');
  if (backupFile && fs.existsSync(backupFile)) {
    res.download(backupFile, path.basename(backupFile));
  } else if (fs.existsSync(config.dbPath)) {
    persistDb();
    res.download(config.dbPath, `tracker-backup-${Date.now()}.db`);
  } else {
    res.status(500).json({ error: 'Database backup failed' });
  }
});

// Serve frontend static build files (SPA)
const frontendDist = path.resolve(__dirname, '../../frontend/dist');
if (fs.existsSync(frontendDist)) {
  app.use(express.static(frontendDist));
  app.get('*', (_req, res) => {
    res.sendFile(path.join(frontendDist, 'index.html'));
  });
} else {
  app.use((_req, res) => { res.status(404).json({ error: 'Not found' }); });
}

app.use((err: Error, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error(err);
  res.status(500).json({ error: 'Internal server error' });
});

async function main() {
  await initDb();
  console.log('✅ Database initialized');

  const server = app.listen(config.port, '0.0.0.0', () => {
    console.log(`🚀 TeamTrack GPS Full-Stack App running on http://localhost:${config.port}`);
    console.log(`   Environment: ${config.nodeEnv}`);
    console.log(`   Static build served from: ${frontendDist}`);
  });

  // Graceful shutdown & crash resilience
  const handleExit = (signal: string) => {
    console.log(`\n🛑 Received ${signal}. Saving database and shutting down gracefully...`);
    closeDb();
    server.close(() => process.exit(0));
  };

  process.on('SIGINT', () => handleExit('SIGINT'));
  process.on('SIGTERM', () => handleExit('SIGTERM'));
  process.on('beforeExit', () => {
    persistDb();
  });
  process.on('uncaughtException', (err) => {
    console.error('💥 Uncaught exception:', err);
    persistDb();
  });
  process.on('unhandledRejection', (reason) => {
    console.error('💥 Unhandled rejection:', reason);
    persistDb();
  });
}

main().catch(console.error);
export default app;
