import { useState, useEffect, useRef } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { api, TeamOption } from '../api';
import {
  Eye,
  EyeOff,
  Navigation,
  UserPlus,
  LogIn,
  Building2,
  User,
  ShieldCheck,
  KeyRound,
  Info,
  ArrowLeft,
  Mail,
  Loader2,
  CheckCircle2,
} from 'lucide-react';

type Screen = 'main' | 'forgot-email' | 'forgot-code';

export function SignInScreen() {
  const { login, register, setAuth } = useAuth();
  const [tab, setTab] = useState<'signin' | 'signup'>('signin');

  // Sign in fields
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showForgotLink, setShowForgotLink] = useState(false);

  // Register fields
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regRole, setRegRole] = useState<'manager' | 'member'>('member');
  const [regTeamId, setRegTeamId] = useState('');
  const [regNewTeamName, setRegNewTeamName] = useState('');
  const [regTeamPassword, setRegTeamPassword] = useState('');

  // Forgot password fields
  const [forgotScreen, setForgotScreen] = useState<Screen>('main');
  const [forgotEmail, setForgotEmail] = useState('');
  const [otpCode, setOtpCode] = useState(['', '', '', '', '', '']);
  const [sentCode, setSentCode] = useState('');
  const [codeSending, setCodeSending] = useState(false);
  const [codeVerifying, setCodeVerifying] = useState(false);
  const [codeMessage, setCodeMessage] = useState('');
  const otpRefs = useRef<(HTMLInputElement | null)[]>([]);

  // Available teams for registration
  const [teams, setTeams] = useState<TeamOption[]>([]);
  const [showPw, setShowPw] = useState(false);
  const [showTeamPw, setShowTeamPw] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const fetchTeams = () => {
    api.auth.teams()
      .then(t => {
        setTeams(t);
        if (t.length > 0 && !regTeamId) setRegTeamId(t[0].id);
      })
      .catch(console.error);
  };

  useEffect(() => {
    fetchTeams();
  }, []);

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    setShowForgotLink(false);
    try {
      await login(loginEmail, loginPassword);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Sign in failed';
      setError(msg);
      // Show forgot password link on auth errors
      if (msg.toLowerCase().includes('invalid') || msg.toLowerCase().includes('password') || msg.toLowerCase().includes('incorrect')) {
        setShowForgotLink(true);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!regName.trim() || !regEmail.trim() || !regPassword) {
      setError('Please fill in all required fields');
      return;
    }

    if (regPassword.length < 6) {
      setError('Your personal password must be at least 6 characters');
      return;
    }

    if (regRole === 'manager') {
      if (!regNewTeamName.trim()) {
        setError('Please enter a team name');
        return;
      }
      if (!regTeamPassword.trim()) {
        setError('Please set a Team Password for teammates to join');
        return;
      }
    } else {
      if (!regTeamId) {
        setError('Please select a team to join. If no teams exist, a manager must register first.');
        return;
      }
      if (!regTeamPassword.trim()) {
        setError('Please enter the Team Password provided by your manager');
        return;
      }
    }

    setLoading(true);
    try {
      await register({
        name: regName.trim(),
        email: regEmail.trim(),
        password: regPassword,
        role: regRole,
        teamId: regRole === 'member' ? regTeamId : undefined,
        teamName: regRole === 'manager' ? regNewTeamName.trim() : undefined,
        teamPassword: regTeamPassword.trim(),
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  // Forgot Password: Request code
  const handleRequestCode = async () => {
    if (!forgotEmail.trim()) {
      setError('Please enter your email address');
      return;
    }
    setError('');
    setCodeSending(true);
    try {
      const result = await api.auth.forgotPassword(forgotEmail.trim());
      setSentCode(result.code);
      setCodeMessage(result.message);
      setForgotScreen('forgot-code');
      setOtpCode(['', '', '', '', '', '']);
      // Auto-focus first OTP input
      setTimeout(() => otpRefs.current[0]?.focus(), 100);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to send code');
    } finally {
      setCodeSending(false);
    }
  };

  // OTP input handler
  const handleOtpChange = (index: number, value: string) => {
    if (!/^\d*$/.test(value)) return; // only digits
    const newCode = [...otpCode];
    newCode[index] = value.slice(-1); // only last digit
    setOtpCode(newCode);

    // Auto-advance to next input
    if (value && index < 5) {
      otpRefs.current[index + 1]?.focus();
    }

    // Auto-submit when all 6 digits entered
    if (newCode.every(d => d !== '') && newCode.join('').length === 6) {
      handleVerifyCode(newCode.join(''));
    }
  };

  const handleOtpKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !otpCode[index] && index > 0) {
      otpRefs.current[index - 1]?.focus();
    }
  };

  const handleOtpPaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const pasted = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6);
    if (pasted.length === 6) {
      const newCode = pasted.split('');
      setOtpCode(newCode);
      handleVerifyCode(pasted);
    }
  };

  // Forgot Password: Verify code and sign in
  const handleVerifyCode = async (codeStr?: string) => {
    const finalCode = codeStr || otpCode.join('');
    if (finalCode.length !== 6) {
      setError('Please enter the complete 6-digit code');
      return;
    }
    setError('');
    setCodeVerifying(true);
    try {
      const result = await api.auth.verifyCode(forgotEmail.trim(), finalCode);
      // Sign in the user
      setAuth(result.token, result.user);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Verification failed');
      setOtpCode(['', '', '', '', '', '']);
      otpRefs.current[0]?.focus();
    } finally {
      setCodeVerifying(false);
    }
  };

  const resetForgot = () => {
    setForgotScreen('main');
    setForgotEmail('');
    setOtpCode(['', '', '', '', '', '']);
    setSentCode('');
    setCodeMessage('');
    setError('');
  };

  // ============ FORGOT PASSWORD: EMAIL SCREEN ============
  if (forgotScreen === 'forgot-email') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 flex flex-col justify-center items-center p-4">
        <div className="w-full max-w-sm bg-white rounded-3xl shadow-2xl p-6">
          <button onClick={resetForgot} className="flex items-center gap-1.5 text-slate-500 text-xs font-medium mb-4 hover:text-slate-700">
            <ArrowLeft className="w-4 h-4" /> Back to Sign In
          </button>

          <div className="text-center mb-6">
            <div className="w-14 h-14 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
              <Mail className="w-7 h-7 text-blue-600" />
            </div>
            <h2 className="text-xl font-bold text-slate-900">Forgot Password?</h2>
            <p className="text-xs text-slate-500 mt-1">Enter your registered email to receive a verification code</p>
          </div>

          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-2xl">
              <p className="text-xs text-red-700 font-medium">⚠️ {error}</p>
            </div>
          )}

          <div className="mb-4">
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">Email Address</label>
            <input
              type="email"
              value={forgotEmail}
              onChange={e => setForgotEmail(e.target.value)}
              placeholder="name@company.com"
              autoFocus
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-slate-900 text-sm placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              onKeyDown={e => e.key === 'Enter' && handleRequestCode()}
            />
          </div>

          <button
            onClick={handleRequestCode}
            disabled={codeSending}
            className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 disabled:bg-blue-300 text-white font-bold rounded-2xl text-sm transition-colors shadow-lg shadow-blue-600/20 flex items-center justify-center gap-2"
          >
            {codeSending ? (
              <><Loader2 className="w-4 h-4 animate-spin" /> Sending Code...</>
            ) : (
              <><Mail className="w-4 h-4" /> Send Verification Code</>
            )}
          </button>
        </div>
      </div>
    );
  }

  // ============ FORGOT PASSWORD: OTP CODE SCREEN ============
  if (forgotScreen === 'forgot-code') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 flex flex-col justify-center items-center p-4">
        <div className="w-full max-w-sm bg-white rounded-3xl shadow-2xl p-6">
          <button onClick={() => setForgotScreen('forgot-email')} className="flex items-center gap-1.5 text-slate-500 text-xs font-medium mb-4 hover:text-slate-700">
            <ArrowLeft className="w-4 h-4" /> Change Email
          </button>

          <div className="text-center mb-6">
            <div className="w-14 h-14 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-3">
              <CheckCircle2 className="w-7 h-7 text-emerald-600" />
            </div>
            <h2 className="text-xl font-bold text-slate-900">Enter Verification Code</h2>
            <p className="text-xs text-slate-500 mt-1">Code sent to <span className="font-semibold text-slate-700">{forgotEmail}</span></p>
          </div>

          {/* Show the code prominently for this local app */}
          {sentCode && (
            <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-2xl text-center">
              <p className="text-[10px] text-blue-600 font-medium uppercase tracking-wider mb-1">Your Verification Code</p>
              <p className="text-2xl font-mono font-bold text-blue-700 tracking-[0.3em]">{sentCode}</p>
              <p className="text-[10px] text-blue-500 mt-1">Valid for 5 minutes</p>
            </div>
          )}

          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-2xl">
              <p className="text-xs text-red-700 font-medium">⚠️ {error}</p>
            </div>
          )}

          {/* 6-digit OTP Input */}
          <div className="flex justify-center gap-2 mb-5" onPaste={handleOtpPaste}>
            {otpCode.map((digit, i) => (
              <input
                key={i}
                ref={el => { otpRefs.current[i] = el; }}
                type="text"
                inputMode="numeric"
                maxLength={1}
                value={digit}
                onChange={e => handleOtpChange(i, e.target.value)}
                onKeyDown={e => handleOtpKeyDown(i, e)}
                className={`w-11 h-14 text-center text-xl font-bold rounded-xl border-2 transition-all focus:outline-none ${
                  digit
                    ? 'border-blue-500 bg-blue-50 text-blue-700'
                    : 'border-slate-200 bg-slate-50 text-slate-900 focus:border-blue-500 focus:bg-blue-50'
                }`}
              />
            ))}
          </div>

          <button
            onClick={() => handleVerifyCode()}
            disabled={codeVerifying || otpCode.join('').length !== 6}
            className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 disabled:bg-emerald-300 text-white font-bold rounded-2xl text-sm transition-colors shadow-lg shadow-emerald-600/20 flex items-center justify-center gap-2"
          >
            {codeVerifying ? (
              <><Loader2 className="w-4 h-4 animate-spin" /> Verifying...</>
            ) : (
              <><CheckCircle2 className="w-4 h-4" /> Verify & Sign In</>
            )}
          </button>

          <button
            onClick={handleRequestCode}
            disabled={codeSending}
            className="w-full mt-3 py-2.5 text-blue-600 font-semibold text-xs hover:bg-blue-50 rounded-xl transition-colors"
          >
            {codeSending ? 'Resending...' : 'Resend Code'}
          </button>
        </div>
      </div>
    );
  }

  // ============ MAIN SIGN IN / SIGN UP SCREEN ============
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 flex flex-col justify-between p-4 sm:p-6">
      <div className="flex-1 flex flex-col items-center justify-center py-6">
        {/* App Logo & Header */}
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center shadow-lg shadow-blue-600/30">
            <Navigation className="w-7 h-7 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight">TN Team</h1>
            <p className="text-blue-300 text-xs font-medium tracking-wider uppercase">GPS Location Platform</p>
          </div>
        </div>
        <p className="text-slate-400 text-xs sm:text-sm text-center mb-6">
          Real-time GPS trip &amp; location tracking for teams
        </p>

        {/* Main Card */}
        <div className="w-full max-w-sm bg-white rounded-3xl shadow-2xl p-6 sm:p-7">
          {/* Tabs: Sign In / Create Account */}
          <div className="flex bg-slate-100 p-1 rounded-2xl mb-5">
            <button
              type="button"
              onClick={() => { setTab('signin'); setError(''); setShowForgotLink(false); }}
              className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                tab === 'signin' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              <LogIn className="w-3.5 h-3.5" />
              Sign In
            </button>
            <button
              type="button"
              onClick={() => { setTab('signup'); setError(''); setShowForgotLink(false); fetchTeams(); }}
              className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                tab === 'signup' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              <UserPlus className="w-3.5 h-3.5" />
              Create Account
            </button>
          </div>

          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-2xl flex items-start gap-2">
              <span className="text-red-500 text-xs mt-0.5 shrink-0">⚠️</span>
              <p className="text-xs text-red-700 font-medium leading-snug">{error}</p>
            </div>
          )}

          {tab === 'signin' ? (
            /* SIGN IN FORM */
            <form onSubmit={handleSignIn} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">Email Address</label>
                <input
                  type="email"
                  value={loginEmail}
                  onChange={e => setLoginEmail(e.target.value)}
                  placeholder="name@company.com"
                  required
                  autoComplete="email"
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-slate-900 text-sm placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">Password</label>
                <div className="relative">
                  <input
                    type={showPw ? 'text' : 'password'}
                    value={loginPassword}
                    onChange={e => setLoginPassword(e.target.value)}
                    placeholder="Enter your password"
                    required
                    autoComplete="current-password"
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-slate-900 text-sm placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition pr-11"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPw(!showPw)}
                    className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1"
                  >
                    {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Forgot Password Link — shown after wrong password */}
              {showForgotLink && (
                <button
                  type="button"
                  onClick={() => {
                    setForgotEmail(loginEmail);
                    setForgotScreen('forgot-email');
                    setError('');
                  }}
                  className="w-full text-center text-xs font-semibold text-blue-600 hover:text-blue-700 py-1 transition-colors"
                >
                  🔑 Forgot Password? Get a verification code
                </button>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 disabled:bg-blue-300 text-white font-bold rounded-2xl text-sm transition-colors shadow-lg shadow-blue-600/20 mt-2"
              >
                {loading ? 'Signing in...' : 'Sign In'}
              </button>
            </form>
          ) : (
            /* CREATE ACCOUNT (SIGN UP) FORM */
            <form onSubmit={handleSignUp} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Your Full Name</label>
                <input
                  type="text"
                  value={regName}
                  onChange={e => setRegName(e.target.value)}
                  placeholder="e.g. John Doe"
                  required
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-sm placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Your Email</label>
                <input
                  type="email"
                  value={regEmail}
                  onChange={e => setRegEmail(e.target.value)}
                  placeholder="john@company.com"
                  required
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-sm placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Your Personal Password</label>
                <div className="relative">
                  <input
                    type={showPw ? 'text' : 'password'}
                    value={regPassword}
                    onChange={e => setRegPassword(e.target.value)}
                    placeholder="At least 6 characters"
                    required
                    minLength={6}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-sm placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPw(!showPw)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Role Picker */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Select Role</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setRegRole('member')}
                    className={`py-2 px-3 rounded-xl text-xs font-semibold border flex items-center justify-center gap-1.5 transition-all ${
                      regRole === 'member'
                        ? 'border-blue-600 bg-blue-50 text-blue-700 ring-1 ring-blue-600'
                        : 'border-slate-200 bg-white text-slate-600'
                    }`}
                  >
                    <User className="w-3.5 h-3.5" />
                    Teammate
                  </button>
                  <button
                    type="button"
                    onClick={() => setRegRole('manager')}
                    className={`py-2 px-3 rounded-xl text-xs font-semibold border flex items-center justify-center gap-1.5 transition-all ${
                      regRole === 'manager'
                        ? 'border-purple-600 bg-purple-50 text-purple-700 ring-1 ring-purple-600'
                        : 'border-slate-200 bg-white text-slate-600'
                    }`}
                  >
                    <ShieldCheck className="w-3.5 h-3.5" />
                    Manager
                  </button>
                </div>
              </div>

              {/* MANAGER: CREATE TEAM & SET JOIN PASSWORD */}
              {regRole === 'manager' ? (
                <div className="bg-purple-50/70 border border-purple-200/80 rounded-2xl p-3 space-y-2.5">
                  <div>
                    <label className="block text-xs font-bold text-purple-900 mb-1">Create Team Name</label>
                    <input
                      type="text"
                      value={regNewTeamName}
                      onChange={e => setRegNewTeamName(e.target.value)}
                      placeholder="e.g. TN Logistics"
                      required
                      className="w-full px-3.5 py-2 bg-white border border-purple-200 rounded-xl text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-purple-900 mb-1 flex items-center gap-1">
                      <KeyRound className="w-3.5 h-3.5 text-purple-600" />
                      Set Unique Team Password
                    </label>
                    <div className="relative">
                      <input
                        type={showTeamPw ? 'text' : 'password'}
                        value={regTeamPassword}
                        onChange={e => setRegTeamPassword(e.target.value)}
                        placeholder="e.g. TN@Team2026"
                        required
                        className="w-full px-3.5 py-2 bg-white border border-purple-200 rounded-xl text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 pr-10"
                      />
                      <button
                        type="button"
                        onClick={() => setShowTeamPw(!showTeamPw)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                      >
                        {showTeamPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                    <p className="text-[10px] text-purple-700 mt-1 flex items-center gap-1 leading-tight">
                      <Info className="w-3 h-3 shrink-0" />
                      Teammates will need this password to join your team.
                    </p>
                  </div>
                </div>
              ) : (
                /* TEAMMATE: SELECT TEAM & ENTER JOIN PASSWORD */
                <div className="bg-blue-50/70 border border-blue-200/80 rounded-2xl p-3 space-y-2.5">
                  <div>
                    <label className="block text-xs font-bold text-blue-900 mb-1">Select Team to Join</label>
                    {teams.length === 0 ? (
                      <div className="p-2.5 bg-white border border-amber-200 rounded-xl text-xs text-amber-800">
                        No teams created yet. A manager must register first to create a team.
                      </div>
                    ) : (
                      <div className="relative">
                        <select
                          value={regTeamId}
                          onChange={e => setRegTeamId(e.target.value)}
                          className="w-full px-3.5 py-2 bg-white border border-blue-200 rounded-xl text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 appearance-none"
                        >
                          {teams.map(t => (
                            <option key={t.id} value={t.id}>
                              {t.name} ({t.member_count} members)
                            </option>
                          ))}
                        </select>
                        <Building2 className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-blue-900 mb-1 flex items-center gap-1">
                      <KeyRound className="w-3.5 h-3.5 text-blue-600" />
                      Team Password (from Manager)
                    </label>
                    <div className="relative">
                      <input
                        type={showTeamPw ? 'text' : 'password'}
                        value={regTeamPassword}
                        onChange={e => setRegTeamPassword(e.target.value)}
                        placeholder="Enter the team join password"
                        required
                        className="w-full px-3.5 py-2 bg-white border border-blue-200 rounded-xl text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 pr-10"
                      />
                      <button
                        type="button"
                        onClick={() => setShowTeamPw(!showTeamPw)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                      >
                        {showTeamPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                    <p className="text-[10px] text-blue-700 mt-1 flex items-center gap-1 leading-tight">
                      <Info className="w-3 h-3 shrink-0" />
                      Ask your manager for the team join password.
                    </p>
                  </div>
                </div>
              )}

              <button
                type="submit"
                disabled={loading || (regRole === 'member' && teams.length === 0)}
                className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 disabled:bg-blue-300 text-white font-bold rounded-2xl text-sm transition-colors shadow-lg shadow-blue-600/20 mt-2"
              >
                {loading ? 'Creating account...' : 'Create Account & Enter'}
              </button>
            </form>
          )}
        </div>
      </div>

      {/* Privacy note */}
      <p className="text-center text-[11px] text-slate-400 max-w-sm mx-auto leading-relaxed">
        Location data is only tracked during active trips. Every query is protected by team membership and backend RBAC.
      </p>
    </div>
  );
}
