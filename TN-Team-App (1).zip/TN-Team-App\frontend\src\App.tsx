import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { SignInScreen } from './screens/SignInScreen';
import { MapHomeScreen } from './screens/MapHomeScreen';
import { ManagerMapScreen } from './screens/ManagerMapScreen';
import { HistoryScreen } from './screens/HistoryScreen';
import { TripDetailScreen } from './screens/TripDetailScreen';
import { TeamListScreen } from './screens/TeamListScreen';
import { TeamMemberDetailScreen } from './screens/TeamMemberDetailScreen';
import { SettingsScreen } from './screens/SettingsScreen';
import { DailyEntryScreen } from './screens/DailyEntryScreen';
import { ManagerDailyScreen } from './screens/ManagerDailyScreen';
import { BottomNav } from './components/BottomNav';
import { LoadingSpinner } from './components/States';

function AppRoutes() {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return <LoadingSpinner fullScreen message="Loading TN Team..." />;
  }

  if (!user) {
    return <SignInScreen />;
  }

  const isDetailPage = location.pathname.startsWith('/trips/') || location.pathname.startsWith('/team/');
  const isManager = user.role === 'manager';

  return (
    <div className="min-h-screen bg-slate-950 flex justify-center items-center sm:p-4">
      {/* Phone container mockup on desktop screens, full native bleed on mobile devices */}
      <div className="w-full sm:max-w-[420px] h-[100dvh] sm:h-[880px] sm:max-h-[92vh] sm:rounded-[44px] bg-slate-50 flex flex-col shadow-2xl relative overflow-hidden sm:border-[8px] sm:border-slate-800">
        
        {/* Dynamic Island / Speaker notch on desktop frame */}
        <div className="hidden sm:flex justify-center pt-2.5 pb-1 bg-slate-50 z-40 shrink-0">
          <div className="w-24 h-4 bg-slate-900 rounded-full flex items-center justify-end pr-2">
            <div className="w-2 h-2 rounded-full bg-slate-800" />
          </div>
        </div>

        {/* Screen View */}
        <main className="flex-1 relative overflow-hidden flex flex-col">
          <Routes>
            <Route path="/" element={isManager ? <ManagerMapScreen /> : <MapHomeScreen />} />
            <Route path="/personal-map" element={<MapHomeScreen />} />
            <Route path="/history" element={<HistoryScreen />} />
            <Route path="/daily" element={isManager ? <ManagerDailyScreen /> : <DailyEntryScreen />} />
            <Route path="/trips/:id" element={<TripDetailScreen />} />
            
            {/* Manager only routes */}
            {isManager && (
              <>
                <Route path="/team" element={<TeamListScreen />} />
                <Route path="/team/:userId" element={<TeamMemberDetailScreen />} />
              </>
            )}

            <Route path="/settings" element={<SettingsScreen />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>

        {/* Navigation Bar */}
        {!isDetailPage && <BottomNav />}
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppRoutes />
    </AuthProvider>
  );
}
