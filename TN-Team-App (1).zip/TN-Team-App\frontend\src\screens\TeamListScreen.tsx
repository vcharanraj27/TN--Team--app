import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { api } from '../api';
import { TeamMember } from '../types';
import { Avatar } from '../components/Avatar';
import { LoadingSpinner, ErrorBanner, EmptyState } from '../components/States';
import { timeAgo } from '../utils';
import {
  ChevronRight,
  Activity,
  Clock,
  Users,
  Search,
  UserMinus,
  AlertTriangle,
  Loader2,
  Trash2,
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export function TeamListScreen() {
  const { token, user } = useAuth();
  const navigate = useNavigate();
  const [members, setMembers] = useState<TeamMember[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Removal state
  const [memberToRemove, setMemberToRemove] = useState<TeamMember | null>(null);
  const [removing, setRemoving] = useState(false);
  const [removeError, setRemoveError] = useState('');

  const loadTeam = () => {
    if (!token) return;
    setLoading(true);
    api.manager.team(token)
      .then(setMembers)
      .catch(e => setError(e.message))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadTeam();
  }, [token]);

  const handleConfirmRemove = async () => {
    if (!token || !memberToRemove) return;
    setRemoving(true);
    setRemoveError('');
    try {
      await api.manager.deleteMember(token, memberToRemove.id);
      setMembers(prev => prev.filter(m => m.id !== memberToRemove.id));
      setMemberToRemove(null);
    } catch (e) {
      setRemoveError(e instanceof Error ? e.message : 'Failed to remove teammate');
    } finally {
      setRemoving(false);
    }
  };

  const activeCount = members.filter(m => m.active_status === 'active').length;
  const filtered = members.filter(m =>
    m.name.toLowerCase().includes(search.toLowerCase()) ||
    m.email.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="h-full flex flex-col bg-slate-50 relative">
      {/* HEADER */}
      <div className="bg-white/95 backdrop-blur-md px-4 pt-12 pb-4 border-b border-slate-200/80 sticky top-0 z-20">
        <div className="flex items-center justify-between mb-2">
          <div>
            <h1 className="text-xl font-black text-slate-900 tracking-tight">Team Members</h1>
            <p className="text-xs text-slate-500 font-medium">{user?.teamName}</p>
          </div>
          <span className="px-3 py-1 bg-purple-50 text-purple-700 font-bold rounded-xl text-xs">
            {members.length} Total
          </span>
        </div>

        {/* Search input */}
        <div className="relative mt-3">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search member by name or email..."
            className="w-full pl-9 pr-4 py-2.5 bg-slate-100 border-none rounded-2xl text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
        </div>
      </div>

      {loading ? (
        <LoadingSpinner message="Loading team members..." />
      ) : error ? (
        <ErrorBanner message={error} />
      ) : members.length === 0 ? (
        <EmptyState
          icon={<Users className="w-12 h-12" />}
          title="No team members yet"
          description="Give your Team Password to teammates so they can join your team."
        />
      ) : (
        <div className="flex-1 overflow-y-auto px-4 pt-4 pb-24 space-y-2.5">
          {filtered.map(member => (
            <div
              key={member.id}
              className="w-full bg-white border border-slate-100 rounded-3xl p-3.5 shadow-sm hover:shadow-md transition-all flex items-center gap-3 text-left"
            >
              <div
                onClick={() => navigate(`/team/${member.id}`)}
                className="flex items-center gap-3.5 flex-1 min-w-0 cursor-pointer"
              >
                <div className="relative shrink-0">
                  <Avatar name={member.name} color={member.avatar_color} size="md" />
                  {member.active_status === 'active' && (
                    <span className="absolute -top-0.5 -right-0.5 w-3.5 h-3.5 bg-green-500 rounded-full border-2 border-white tracking-pulse" />
                  )}
                  {member.active_status === 'paused' && (
                    <span className="absolute -top-0.5 -right-0.5 w-3.5 h-3.5 bg-amber-500 rounded-full border-2 border-white" />
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="text-xs font-black text-slate-900 truncate">{member.name}</p>
                    {member.role === 'manager' && (
                      <span className="text-[10px] font-bold bg-purple-100 text-purple-700 px-2 py-0.5 rounded-md">Manager</span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-400 truncate">{member.email}</p>

                  <div className="flex items-center gap-2 mt-1">
                    {member.active_status === 'active' ? (
                      <span className="flex items-center gap-1 text-[11px] font-bold text-green-600">
                        <Activity className="w-3 h-3" /> Live Tracking
                      </span>
                    ) : member.active_status === 'paused' ? (
                      <span className="flex items-center gap-1 text-[11px] font-bold text-amber-600">
                        <Activity className="w-3 h-3" /> Paused
                      </span>
                    ) : member.last_seen ? (
                      <span className="flex items-center gap-1 text-[11px] text-slate-400">
                        <Clock className="w-3 h-3" /> Seen {timeAgo(member.last_seen)}
                      </span>
                    ) : (
                      <span className="text-[11px] text-slate-400">No telemetry</span>
                    )}
                    <span className="text-slate-300 text-xs">•</span>
                    <span className="text-[11px] font-semibold text-slate-400 font-mono">{member.trip_count} trips</span>
                  </div>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex items-center gap-1 shrink-0">
                {user?.role === 'manager' && member.role !== 'manager' && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setMemberToRemove(member);
                      setRemoveError('');
                    }}
                    className="p-2 rounded-xl text-slate-400 hover:text-red-600 hover:bg-red-50 active:scale-95 transition-all"
                    title="Remove Teammate"
                  >
                    <UserMinus className="w-4 h-4" />
                  </button>
                )}
                <button
                  onClick={() => navigate(`/team/${member.id}`)}
                  className="p-1 text-slate-300 hover:text-slate-500"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* CONFIRMATION MODAL */}
      {memberToRemove && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-3xl shadow-2xl p-5 slide-up">
            <div className="w-12 h-12 bg-red-100 text-red-600 rounded-2xl flex items-center justify-center mx-auto mb-3 shadow-inner">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <h3 className="text-base font-bold text-slate-900 text-center mb-1">
              Remove Teammate?
            </h3>
            <p className="text-xs text-slate-500 text-center leading-relaxed mb-4">
              Are you sure you want to remove <strong className="text-slate-800">{memberToRemove.name}</strong> ({memberToRemove.email}) from the team?
            </p>

            <div className="bg-red-50 border border-red-200/80 rounded-2xl p-3 mb-4 text-[11px] text-red-700 leading-relaxed">
              ⚠️ This will remove their profile and delete all their recorded trips, locations, daily reports, and targets from this team.
            </div>

            {removeError && (
              <div className="mb-3 p-2.5 bg-red-100 text-red-700 text-xs rounded-xl font-medium">
                {removeError}
              </div>
            )}

            <div className="flex gap-2.5">
              <button
                type="button"
                onClick={() => { setMemberToRemove(null); setRemoveError(''); }}
                disabled={removing}
                className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-2xl text-xs transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmRemove}
                disabled={removing}
                className="flex-1 py-3 bg-red-600 hover:bg-red-700 active:bg-red-800 text-white font-bold rounded-2xl text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-red-600/30 transition-all disabled:opacity-50"
              >
                {removing ? (
                  <><Loader2 className="w-4 h-4 animate-spin" /> Removing...</>
                ) : (
                  <><Trash2 className="w-4 h-4" /> Confirm &amp; Remove</>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
