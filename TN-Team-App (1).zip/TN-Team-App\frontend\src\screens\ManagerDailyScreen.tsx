import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { api } from '../api';
import { TeamMemberDaily, TeamMTD, ManagerComment, DailyEntry, DailyMTD, MonthlyTarget } from '../types';
import {
  IndianRupee,
  TrendingUp,
  Activity,
  MessageCircle,
  Send,
  Calendar,
  Users,
  ChevronDown,
  ChevronUp,
  Loader2,
  Save,
  CheckCircle2,
  ShieldCheck,
  FileText,
  Search,
  X,
  Sparkles,
  Target,
  Briefcase,
  Lock,
  AlertCircle,
  Check,
} from 'lucide-react';

export function ManagerDailyScreen() {
  const { token, user } = useAuth();

  // Active Screen Tab: 'team' or 'my-entry'
  const [activeTab, setActiveTab] = useState<'team' | 'my-entry'>('team');

  // Team Dashboard State
  const [period, setPeriod] = useState<'today' | 'month'>('today');
  const [teamDaily, setTeamDaily] = useState<TeamMemberDaily[]>([]);
  const [teamMtd, setTeamMtd] = useState<TeamMTD | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedMember, setExpandedMember] = useState<string | null>(null);
  const [commentInputs, setCommentInputs] = useState<Record<string, string>>({});
  const [memberComments, setMemberComments] = useState<Record<string, ManagerComment[]>>({});
  const [sendingCommentId, setSendingCommentId] = useState<string | null>(null);

  // Full History Modal for individual teammate
  const [historyModalMember, setHistoryModalMember] = useState<{ id: string; name: string; role?: string } | null>(null);
  const [memberHistoryEntries, setMemberHistoryEntries] = useState<DailyEntry[]>([]);
  const [memberHistoryMonthlyTarget, setMemberHistoryMonthlyTarget] = useState<MonthlyTarget | null>(null);
  const [loadingHistory, setLoadingHistory] = useState(false);

  // Manager Personal Entry State (Actuals + Daily Targets)
  const [myEntryMode, setMyEntryMode] = useState<'actual' | 'target'>('actual');
  const [mySales, setMySales] = useState('');
  const [myCollection, setMyCollection] = useState('');
  const [myActivity, setMyActivity] = useState('');
  const [myNewPd, setMyNewPd] = useState('');
  const [myNotes, setMyNotes] = useState('');

  const [myTargetSales, setMyTargetSales] = useState('');
  const [myTargetCollection, setMyTargetCollection] = useState('');
  const [myTargetActivity, setMyTargetActivity] = useState('');
  const [myTargetNewPd, setMyTargetNewPd] = useState('');

  // Manager Monthly Target Modal
  const [showManagerMonthlyModal, setShowManagerMonthlyModal] = useState(false);
  const [mMgrSales, setMMgrSales] = useState('');
  const [mMgrCollection, setMMgrCollection] = useState('');
  const [mMgrActivity, setMMgrActivity] = useState('');
  const [mMgrNewPd, setMMgrNewPd] = useState('');
  const [savingMgrMonthlyTarget, setSavingMgrMonthlyTarget] = useState(false);
  const [mgrMonthlyTargetError, setMgrMonthlyTargetError] = useState('');

  const [mySaving, setMySaving] = useState(false);
  const [mySaved, setMySaved] = useState(false);
  const [myMtd, setMyMtd] = useState<DailyMTD | null>(null);

  const [loading, setLoading] = useState(true);

  const today = new Date();
  const dateStr = today.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'long' });
  const monthStr = today.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });

  const loadData = useCallback(async () => {
    if (!token) return;
    try {
      setLoading(true);
      const [daily, mtd, myEntry, myMtdData] = await Promise.all([
        api.daily.teamDaily(token),
        api.daily.teamMtd(token),
        api.daily.get(token),
        api.daily.mtd(token),
      ]);
      setTeamDaily(daily);
      setTeamMtd(mtd);

      // Actuals
      setMySales(myEntry.sales_amount ? String(myEntry.sales_amount) : '');
      setMyCollection(myEntry.collection_amount ? String(myEntry.collection_amount) : '');
      setMyActivity(myEntry.activity_count ? String(myEntry.activity_count) : '');
      setMyNewPd(myEntry.new_pd_count ? String(myEntry.new_pd_count) : '');
      setMyNotes(myEntry.notes || '');

      // Daily Targets
      setMyTargetSales(myEntry.target_sales ? String(myEntry.target_sales) : '');
      setMyTargetCollection(myEntry.target_collection ? String(myEntry.target_collection) : '');
      setMyTargetActivity(myEntry.target_activity ? String(myEntry.target_activity) : '');
      setMyTargetNewPd(myEntry.target_new_pd ? String(myEntry.target_new_pd) : '');

      setMyMtd(myMtdData);
    } catch (e) {
      console.error('Failed to load daily data:', e);
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(val);
  };

  const calcPercent = (actual: number, target: number) => {
    if (!target || target <= 0) return null;
    return Math.min(Math.round((actual / target) * 100), 999);
  };

  const handleSaveMyEntry = async () => {
    if (!token) return;
    setMySaving(true);
    try {
      await api.daily.save(token, {
        sales_amount: parseFloat(mySales) || 0,
        collection_amount: parseFloat(myCollection) || 0,
        activity_count: parseInt(myActivity) || 0,
        new_pd_count: parseInt(myNewPd) || 0,
        target_sales: parseFloat(myTargetSales) || 0,
        target_collection: parseFloat(myTargetCollection) || 0,
        target_activity: parseInt(myTargetActivity) || 0,
        target_new_pd: parseInt(myTargetNewPd) || 0,
        notes: myNotes,
      });
      setMySaved(true);
      setTimeout(() => setMySaved(false), 2000);
      const [updatedMyMtd, updatedTeamDaily, updatedTeamMtd] = await Promise.all([
        api.daily.mtd(token),
        api.daily.teamDaily(token),
        api.daily.teamMtd(token),
      ]);
      setMyMtd(updatedMyMtd);
      setTeamDaily(updatedTeamDaily);
      setTeamMtd(updatedTeamMtd);
    } catch (e) {
      console.error('Failed to save manager entry:', e);
    } finally {
      setMySaving(false);
    }
  };

  const handleSaveManagerMonthlyTarget = async () => {
    if (!token) return;
    setMgrMonthlyTargetError('');
    setSavingMgrMonthlyTarget(true);
    try {
      await api.daily.setMonthlyTarget(token, {
        target_sales: parseFloat(mMgrSales) || 0,
        target_collection: parseFloat(mMgrCollection) || 0,
        target_activity: parseInt(mMgrActivity) || 0,
        target_new_pd: parseInt(mMgrNewPd) || 0,
      });
      setShowManagerMonthlyModal(false);
      const [updatedMyMtd, updatedTeamDaily, updatedTeamMtd] = await Promise.all([
        api.daily.mtd(token),
        api.daily.teamDaily(token),
        api.daily.teamMtd(token),
      ]);
      setMyMtd(updatedMyMtd);
      setTeamDaily(updatedTeamDaily);
      setTeamMtd(updatedTeamMtd);
    } catch (err) {
      setMgrMonthlyTargetError(err instanceof Error ? err.message : 'Failed to save monthly target');
    } finally {
      setSavingMgrMonthlyTarget(false);
    }
  };

  const toggleMember = async (memberId: string) => {
    if (expandedMember === memberId) {
      setExpandedMember(null);
      return;
    }
    setExpandedMember(memberId);
    if (!memberComments[memberId] && token) {
      try {
        const comments = await api.daily.memberComments(token, memberId);
        setMemberComments(prev => ({ ...prev, [memberId]: comments }));
      } catch (e) {
        console.error('Failed to load comments:', e);
      }
    }
  };

  const handleSendComment = async (memberId: string) => {
    const text = (commentInputs[memberId] || '').trim();
    if (!token || !text) return;
    setSendingCommentId(memberId);
    try {
      const comment = await api.daily.postComment(token, { memberId, comment: text });
      setMemberComments(prev => ({
        ...prev,
        [memberId]: [...(prev[memberId] || []), comment],
      }));
      setCommentInputs(prev => ({ ...prev, [memberId]: '' }));
    } catch (e) {
      console.error('Failed to send comment:', e);
    } finally {
      setSendingCommentId(null);
    }
  };

  const handleOpenHistoryModal = async (memberId: string, memberName: string, memberRole?: string) => {
    if (!token) return;
    setHistoryModalMember({ id: memberId, name: memberName, role: memberRole });
    setLoadingHistory(true);
    try {
      const res = await api.daily.memberHistory(token, memberId);
      setMemberHistoryEntries(res.entries || []);
      setMemberHistoryMonthlyTarget(res.monthlyTarget || null);
    } catch (e) {
      console.error('Failed to load member history:', e);
      setMemberHistoryEntries([]);
      setMemberHistoryMonthlyTarget(null);
    } finally {
      setLoadingHistory(false);
    }
  };

  // Calculate today's team totals
  const todayTotals = teamDaily.reduce(
    (acc, m) => ({
      sales: acc.sales + (m.sales_amount || 0),
      collection: acc.collection + (m.collection_amount || 0),
      activity: acc.activity + (m.activity_count || 0),
      new_pd: acc.new_pd + (m.new_pd_count || 0),
    }),
    { sales: 0, collection: 0, activity: 0, new_pd: 0 }
  );

  const filteredTeamDaily = teamDaily.filter(m =>
    m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    m.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center bg-gradient-to-b from-indigo-50 to-slate-50">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
      </div>
    );
  }

  const mgrMonthlyTarget = myMtd?.monthlyTarget;
  const mgrTargetWindow = myMtd?.targetWindow;

  return (
    <div className="flex-1 overflow-y-auto bg-gradient-to-b from-indigo-50 via-white to-slate-50 relative pb-28">
      {/* Header */}
      <div className="px-5 pt-6 pb-3">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Performance &amp; Targets</h1>
            <p className="text-xs text-slate-500 mt-0.5">{dateStr}</p>
          </div>
          <span className="px-3 py-1 bg-indigo-100 text-indigo-700 font-bold text-xs rounded-full flex items-center gap-1 shadow-sm">
            <ShieldCheck className="w-4 h-4 text-indigo-600" /> Manager View
          </span>
        </div>

        {/* Primary Tabs */}
        <div className="flex bg-slate-200/90 p-1 rounded-2xl mt-4 shadow-inner">
          <button
            onClick={() => setActiveTab('team')}
            className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'team' ? 'bg-white text-indigo-700 shadow-md scale-[1.01]' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Users className="w-4 h-4" />
            Teammates ({teamDaily.length})
          </button>
          <button
            onClick={() => setActiveTab('my-entry')}
            className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'my-entry' ? 'bg-white text-indigo-700 shadow-md scale-[1.01]' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Sparkles className="w-4 h-4 text-amber-500" />
            My Report &amp; Targets
          </button>
        </div>
      </div>

      {activeTab === 'team' ? (
        /* ==================== TEAMMATES DASHBOARD & INDIVIDUAL REPORTS ==================== */
        <div className="px-5 space-y-4">
          {/* Timeframe Toggle: Today vs Month */}
          <div className="flex bg-slate-100 p-1 rounded-xl">
            <button
              onClick={() => setPeriod('today')}
              className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${
                period === 'today' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500'
              }`}
            >
              <Calendar className="w-3.5 h-3.5 inline mr-1" />
              Today's Performance
            </button>
            <button
              onClick={() => setPeriod('month')}
              className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${
                period === 'month' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500'
              }`}
            >
              <TrendingUp className="w-3.5 h-3.5 inline mr-1" />
              Month MTD ({monthStr.split(' ')[0]})
            </button>
          </div>

          {/* Aggregate Overview Card (4 Metrics: Sales, Collection, Activity, New PD) */}
          {period === 'today' ? (
            <div className="bg-gradient-to-r from-indigo-600 via-blue-600 to-indigo-700 rounded-3xl p-5 text-white shadow-xl shadow-indigo-500/20">
              <div className="flex items-center justify-between mb-3">
                <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-100">Team Total • Today</span>
                <span className="text-[10px] bg-white/20 px-2 py-0.5 rounded-full font-medium">{teamDaily.length} members</span>
              </div>
              <div className="grid grid-cols-4 gap-1.5 text-center">
                <div className="bg-white/10 rounded-2xl p-2 backdrop-blur-sm">
                  <p className="text-sm sm:text-base font-black tracking-tight">{formatCurrency(todayTotals.sales)}</p>
                  <p className="text-[9px] text-indigo-100 mt-0.5 font-medium">Sales</p>
                </div>
                <div className="bg-white/10 rounded-2xl p-2 backdrop-blur-sm">
                  <p className="text-sm sm:text-base font-black tracking-tight">{formatCurrency(todayTotals.collection)}</p>
                  <p className="text-[9px] text-indigo-100 mt-0.5 font-medium">Collection</p>
                </div>
                <div className="bg-white/10 rounded-2xl p-2 backdrop-blur-sm">
                  <p className="text-sm sm:text-base font-black tracking-tight">{todayTotals.activity}</p>
                  <p className="text-[8px] text-indigo-100 mt-0.5 font-medium leading-tight">Farmer's Visit/Meating</p>
                </div>
                <div className="bg-white/10 rounded-2xl p-2 backdrop-blur-sm">
                  <p className="text-sm sm:text-base font-black tracking-tight">{todayTotals.new_pd}</p>
                  <p className="text-[9px] text-indigo-100 mt-0.5 font-medium">New PD</p>
                </div>
              </div>
            </div>
          ) : teamMtd && (
            <div className="bg-gradient-to-r from-purple-700 via-indigo-600 to-blue-600 rounded-3xl p-5 text-white shadow-xl shadow-purple-500/20">
              <div className="flex items-center justify-between mb-3">
                <span className="text-[11px] font-bold uppercase tracking-wider text-purple-100">Team Total • {monthStr}</span>
                <span className="text-[10px] bg-white/20 px-2 py-0.5 rounded-full font-medium">Month to Date</span>
              </div>
              <div className="grid grid-cols-4 gap-1.5 text-center">
                <div className="bg-white/10 rounded-2xl p-2 backdrop-blur-sm">
                  <p className="text-sm sm:text-base font-black tracking-tight">{formatCurrency(teamMtd.teamTotal.total_sales)}</p>
                  <p className="text-[9px] text-purple-100 mt-0.5 font-medium">Sales</p>
                </div>
                <div className="bg-white/10 rounded-2xl p-2 backdrop-blur-sm">
                  <p className="text-sm sm:text-base font-black tracking-tight">{formatCurrency(teamMtd.teamTotal.total_collection)}</p>
                  <p className="text-[9px] text-purple-100 mt-0.5 font-medium">Collection</p>
                </div>
                <div className="bg-white/10 rounded-2xl p-2 backdrop-blur-sm">
                  <p className="text-sm sm:text-base font-black tracking-tight">{teamMtd.teamTotal.total_activity}</p>
                  <p className="text-[8px] text-purple-100 mt-0.5 font-medium leading-tight">Farmer's Visit/Meating</p>
                </div>
                <div className="bg-white/10 rounded-2xl p-2 backdrop-blur-sm">
                  <p className="text-sm sm:text-base font-black tracking-tight">{teamMtd.teamTotal.total_new_pd}</p>
                  <p className="text-[9px] text-purple-100 mt-0.5 font-medium">New PD</p>
                </div>
              </div>
            </div>
          )}

          {/* Search bar */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search teammates..."
              className="w-full pl-9 pr-4 py-2 bg-white border border-slate-200 rounded-2xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* TODAY'S TEAMMATES LIST (WITH 4 METRICS, TARGETS, & COMMENTS) */}
          {period === 'today' ? (
            <div className="space-y-3">
              <p className="text-xs font-bold text-slate-500 uppercase tracking-wider px-1">
                Individual Performance ({filteredTeamDaily.length})
              </p>

              {filteredTeamDaily.length === 0 ? (
                <div className="bg-white rounded-3xl p-8 text-center shadow-sm border border-slate-100">
                  <Users className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                  <p className="text-xs text-slate-400 font-medium">No team members found</p>
                </div>
              ) : (
                filteredTeamDaily.map((member) => {
                  const isSelf = member.id === user?.id;
                  const isExpanded = expandedMember === member.id;
                  const comments = memberComments[member.id] || [];

                  return (
                    <div key={member.id} className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden transition-all">
                      {/* Teammate Header Card */}
                      <div
                        onClick={() => toggleMember(member.id)}
                        className="px-4 py-3.5 flex items-center justify-between cursor-pointer active:bg-slate-50 transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          <div
                            className="w-11 h-11 rounded-2xl flex items-center justify-center text-white text-sm font-bold shadow-md shrink-0"
                            style={{ backgroundColor: member.avatar_color || '#6366f1' }}
                          >
                            {member.name.charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <div className="flex items-center gap-1.5">
                              <p className="text-sm font-bold text-slate-900">{member.name}</p>
                              {member.role === 'manager' && (
                                <span className="px-1.5 py-0.2 bg-purple-100 text-purple-700 text-[9px] font-bold rounded">Manager</span>
                              )}
                              {isSelf && (
                                <span className="px-1.5 py-0.2 bg-blue-100 text-blue-700 text-[9px] font-bold rounded">You</span>
                              )}
                            </div>
                            <div className="flex flex-wrap gap-1 mt-1">
                              <span className="text-[10px] text-emerald-600 font-bold bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-100">
                                {formatCurrency(member.sales_amount)}
                              </span>
                              <span className="text-[10px] text-blue-600 font-bold bg-blue-50 px-1.5 py-0.5 rounded border border-blue-100">
                                {formatCurrency(member.collection_amount)}
                              </span>
                              <span className="text-[10px] text-purple-600 font-bold bg-purple-50 px-1.5 py-0.5 rounded border border-purple-100">
                                {member.activity_count} FV
                              </span>
                              <span className="text-[10px] text-amber-600 font-bold bg-amber-50 px-1.5 py-0.5 rounded border border-amber-100">
                                {member.new_pd_count} PD
                              </span>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              toggleMember(member.id);
                            }}
                            className="p-1.5 rounded-xl bg-slate-100 text-slate-600 text-xs font-semibold flex items-center gap-1 hover:bg-slate-200"
                          >
                            <MessageCircle className="w-3.5 h-3.5 text-amber-500" />
                            {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      </div>

                       {/* Expanded Section: Today Report — Daily Target vs Actual */}
                      {isExpanded && (
                        <div className="px-4 pb-4 border-t border-slate-100 pt-3 space-y-3 bg-slate-50/60">
                          {/* Today Report: Daily Target (left) | Actual (right) */}
                          <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Today's Report</p>
                          <div className="space-y-2">
                            {/* Sales Row */}
                            <div className="flex items-center gap-2 bg-white rounded-2xl p-2.5 border border-emerald-100 shadow-sm">
                              <IndianRupee className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                              <div className="flex-1 grid grid-cols-2 gap-1 text-center">
                                <div className="border-r border-slate-100 pr-2">
                                  <p className="text-[9px] text-slate-400 font-semibold uppercase">Daily Target</p>
                                  <p className="text-xs font-black text-slate-600">{formatCurrency(member.target_sales)}</p>
                                </div>
                                <div className="pl-2">
                                  <p className="text-[9px] text-emerald-600 font-semibold uppercase">Actual</p>
                                  <p className="text-xs font-black text-emerald-700">{formatCurrency(member.sales_amount)}</p>
                                </div>
                              </div>
                              <span className="text-[8px] text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded font-bold shrink-0">Sales</span>
                            </div>

                            {/* Collection Row */}
                            <div className="flex items-center gap-2 bg-white rounded-2xl p-2.5 border border-blue-100 shadow-sm">
                              <TrendingUp className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                              <div className="flex-1 grid grid-cols-2 gap-1 text-center">
                                <div className="border-r border-slate-100 pr-2">
                                  <p className="text-[9px] text-slate-400 font-semibold uppercase">Daily Target</p>
                                  <p className="text-xs font-black text-slate-600">{formatCurrency(member.target_collection)}</p>
                                </div>
                                <div className="pl-2">
                                  <p className="text-[9px] text-blue-600 font-semibold uppercase">Actual</p>
                                  <p className="text-xs font-black text-blue-700">{formatCurrency(member.collection_amount)}</p>
                                </div>
                              </div>
                              <span className="text-[8px] text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded font-bold shrink-0">Colln</span>
                            </div>

                            {/* Farmer's Visit/Meating Row */}
                            <div className="flex items-center gap-2 bg-white rounded-2xl p-2.5 border border-purple-100 shadow-sm">
                              <Activity className="w-3.5 h-3.5 text-purple-500 shrink-0" />
                              <div className="flex-1 grid grid-cols-2 gap-1 text-center">
                                <div className="border-r border-slate-100 pr-2">
                                  <p className="text-[9px] text-slate-400 font-semibold uppercase">Daily Target</p>
                                  <p className="text-xs font-black text-slate-600">{member.target_activity}</p>
                                </div>
                                <div className="pl-2">
                                  <p className="text-[9px] text-purple-600 font-semibold uppercase">Actual</p>
                                  <p className="text-xs font-black text-purple-700">{member.activity_count}</p>
                                </div>
                              </div>
                              <span className="text-[8px] text-purple-600 bg-purple-50 px-1.5 py-0.5 rounded font-bold shrink-0">FV</span>
                            </div>

                            {/* New PD Row */}
                            <div className="flex items-center gap-2 bg-white rounded-2xl p-2.5 border border-amber-100 shadow-sm">
                              <Briefcase className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                              <div className="flex-1 grid grid-cols-2 gap-1 text-center">
                                <div className="border-r border-slate-100 pr-2">
                                  <p className="text-[9px] text-slate-400 font-semibold uppercase">Daily Target</p>
                                  <p className="text-xs font-black text-slate-600">{member.target_new_pd}</p>
                                </div>
                                <div className="pl-2">
                                  <p className="text-[9px] text-amber-600 font-semibold uppercase">Actual</p>
                                  <p className="text-xs font-black text-amber-700">{member.new_pd_count}</p>
                                </div>
                              </div>
                              <span className="text-[8px] text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded font-bold shrink-0">PD</span>
                            </div>
                          </div>

                          {/* Teammate Notes */}
                          {member.notes ? (
                            <div className="bg-white p-3 rounded-2xl border border-slate-200/80">
                              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-0.5">Notes by {member.name}</p>
                              <p className="text-xs text-slate-700 leading-relaxed">{member.notes}</p>
                            </div>
                          ) : (
                            <p className="text-[11px] text-slate-400 italic">No notes written for today.</p>
                          )}

                          {/* Button to View Full Teammate Report & Monthly Targets */}
                          <button
                            type="button"
                            onClick={() => handleOpenHistoryModal(member.id, member.name, member.role)}
                            className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-2xl text-xs flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition-all"
                          >
                            <FileText className="w-3.5 h-3.5" />
                            View Full Month Ledger &amp; Monthly Target
                          </button>

                          {/* Individual Manager Comment Box */}
                          <div className="bg-white rounded-2xl p-3.5 border border-slate-200 shadow-sm">
                            <p className="text-xs font-bold text-slate-900 mb-2 flex items-center gap-1.5">
                              <MessageCircle className="w-4 h-4 text-amber-500" />
                              Discussion &amp; Feedback with {member.name.split(' ')[0]}
                            </p>

                            {/* Comment & Reply Thread */}
                            <div className="space-y-2 mb-3 max-h-48 overflow-y-auto pr-1">
                              {comments.length === 0 ? (
                                <div className="bg-slate-50 p-2.5 rounded-xl text-center">
                                  <p className="text-[11px] text-slate-400 italic">No discussion with this teammate yet.</p>
                                </div>
                              ) : (
                                comments.map((c) => {
                                  const isMgr = c.sender_role === 'manager';
                                  return (
                                    <div
                                      key={c.id}
                                      className={`p-2.5 rounded-xl text-xs ${
                                        isMgr
                                          ? 'bg-amber-50 border border-amber-200 text-slate-900'
                                          : 'bg-blue-50 border border-blue-200 text-slate-900'
                                      }`}
                                    >
                                      <div className="flex items-center justify-between text-[10px] font-bold mb-0.5">
                                        <span className={isMgr ? 'text-amber-800' : 'text-blue-800'}>
                                          {c.sender_name || (isMgr ? 'Manager' : 'Teammate')}
                                        </span>
                                        <span className="text-slate-400 font-normal">
                                          {new Date(c.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}
                                        </span>
                                      </div>
                                      <p className="text-xs text-slate-800">{c.comment}</p>
                                    </div>
                                  );
                                })
                              )}
                            </div>

                            {/* Comment Input */}
                            <div className="flex gap-2">
                              <input
                                type="text"
                                value={commentInputs[member.id] || ''}
                                onChange={e => setCommentInputs({ ...commentInputs, [member.id]: e.target.value })}
                                placeholder={`Write comment for ${member.name.split(' ')[0]}...`}
                                className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                onKeyDown={e => e.key === 'Enter' && handleSendComment(member.id)}
                              />
                              <button
                                type="button"
                                onClick={() => handleSendComment(member.id)}
                                disabled={sendingCommentId === member.id || !(commentInputs[member.id] || '').trim()}
                                className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl active:scale-95 disabled:opacity-40 transition-all flex items-center justify-center gap-1 shadow-sm"
                              >
                                {sendingCommentId === member.id ? (
                                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                ) : (
                                  <>
                                    <Send className="w-3.5 h-3.5" />
                                    <span className="text-[11px] hidden sm:inline">Send</span>
                                  </>
                                )}
                              </button>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          ) : (
            /* MONTHLY MTD LEADERBOARD WITH 4 METRICS & MONTHLY TARGETS */
            <div className="space-y-3">
              <p className="text-xs font-bold text-slate-500 uppercase tracking-wider px-1">
                Month-to-Date Performance ({monthStr})
              </p>

              {teamMtd?.memberTotals.map((m, idx) => (
                <div key={m.id} className="bg-white rounded-3xl p-4 shadow-sm border border-slate-100">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <div
                          className="w-11 h-11 rounded-2xl flex items-center justify-center text-white text-sm font-bold shadow-md"
                          style={{ backgroundColor: m.avatar_color || '#6366f1' }}
                        >
                          {m.name.charAt(0).toUpperCase()}
                        </div>
                        {idx < 3 && (
                          <span className={`absolute -top-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold text-white shadow ${
                            idx === 0 ? 'bg-amber-500' : idx === 1 ? 'bg-slate-400' : 'bg-amber-700'
                          }`}>
                            {idx + 1}
                          </span>
                        )}
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <p className="text-sm font-bold text-slate-900">{m.name}</p>
                          {m.role === 'manager' && (
                            <span className="px-1.5 py-0.2 bg-purple-100 text-purple-700 text-[9px] font-bold rounded">Manager</span>
                          )}
                        </div>
                        <p className="text-[10px] text-slate-400">{m.days_entered} days entered this month</p>
                      </div>
                    </div>
                    <button
                      onClick={() => handleOpenHistoryModal(m.id, m.name, m.role)}
                      className="text-[11px] text-indigo-600 font-bold bg-indigo-50 hover:bg-indigo-100 px-3 py-1.5 rounded-xl transition-colors flex items-center gap-1"
                    >
                      <FileText className="w-3.5 h-3.5" /> Full Ledger
                    </button>
                  </div>

                  {/* 4 MTD Metrics */}
                  <div className="grid grid-cols-4 gap-1.5 mt-3 text-center">
                    <div className="bg-emerald-50 rounded-xl p-1.5 border border-emerald-100/60">
                      <p className="text-[11px] font-black text-emerald-700">{formatCurrency(m.total_sales)}</p>
                      {m.monthly_target_sales ? (
                        <p className="text-[8px] text-slate-400">Tgt: {formatCurrency(m.monthly_target_sales)}</p>
                      ) : null}
                      <p className="text-[8px] text-emerald-600 font-medium">Sales</p>
                    </div>
                    <div className="bg-blue-50 rounded-xl p-1.5 border border-blue-100/60">
                      <p className="text-[11px] font-black text-blue-700">{formatCurrency(m.total_collection)}</p>
                      {m.monthly_target_collection ? (
                        <p className="text-[8px] text-slate-400">Tgt: {formatCurrency(m.monthly_target_collection)}</p>
                      ) : null}
                      <p className="text-[8px] text-blue-600 font-medium">Collection</p>
                    </div>
                    <div className="bg-purple-50 rounded-xl p-1.5 border border-purple-100/60">
                      <p className="text-[11px] font-black text-purple-700">{m.total_activity}</p>
                      {m.monthly_target_activity ? (
                        <p className="text-[8px] text-slate-400">Tgt: {m.monthly_target_activity}</p>
                      ) : null}
                      <p className="text-[8px] text-purple-600 font-medium">FV/Meating</p>
                    </div>
                    <div className="bg-amber-50 rounded-xl p-1.5 border border-amber-100/60">
                      <p className="text-[11px] font-black text-amber-700">{m.total_new_pd}</p>
                      {m.monthly_target_new_pd ? (
                        <p className="text-[8px] text-slate-400">Tgt: {m.monthly_target_new_pd}</p>
                      ) : null}
                      <p className="text-[8px] text-amber-600 font-medium">New PD</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      ) : (
        /* ==================== MANAGER PERSONAL REPORT & TARGETS ==================== */
        <div className="px-5 space-y-4">
          {/* Manager Monthly Target Banner (1st to 7th) */}
          <div className="bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 text-white rounded-3xl p-5 shadow-xl">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Target className="w-5 h-5 text-indigo-400" />
                <div>
                  <h2 className="text-xs font-black uppercase tracking-wider text-indigo-200">
                    Manager Monthly Target • {monthStr}
                  </h2>
                  <p className="text-[10px] text-slate-400">
                    {mgrMonthlyTarget ? 'Target locked for this month' : 'Settable once between 1st & 7th'}
                  </p>
                </div>
              </div>

              {mgrMonthlyTarget ? (
                <span className="px-2.5 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold rounded-full flex items-center gap-1">
                  <Lock className="w-3 h-3" /> Locked
                </span>
              ) : mgrTargetWindow?.isOpen ? (
                <button
                  onClick={() => {
                    setShowManagerMonthlyModal(true);
                    setMgrMonthlyTargetError('');
                  }}
                  className="px-3 py-1.5 bg-gradient-to-r from-amber-500 to-orange-500 text-white text-[11px] font-bold rounded-xl shadow-lg active:scale-95 transition-transform flex items-center gap-1"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-200" />
                  Set Monthly Target
                </button>
              ) : (
                <span className="px-2.5 py-1 bg-red-500/20 text-red-300 border border-red-500/30 text-[10px] font-bold rounded-full flex items-center gap-1">
                  <Lock className="w-3 h-3" /> Window Closed
                </span>
              )}
            </div>

            {mgrMonthlyTarget && (
              <div className="grid grid-cols-2 gap-2 text-xs mt-3">
                <div className="bg-white/10 rounded-2xl p-2.5">
                  <p className="text-[10px] text-indigo-200">Monthly Sales Target</p>
                  <p className="text-sm font-black text-emerald-400">{formatCurrency(mgrMonthlyTarget.target_sales)}</p>
                </div>
                <div className="bg-white/10 rounded-2xl p-2.5">
                  <p className="text-[10px] text-indigo-200">Monthly Collection Target</p>
                  <p className="text-sm font-black text-blue-400">{formatCurrency(mgrMonthlyTarget.target_collection)}</p>
                </div>
                <div className="bg-white/10 rounded-2xl p-2.5">
                  <p className="text-[10px] text-indigo-200">Farmer's Visit/Meating Target</p>
                  <p className="text-sm font-black text-purple-400">{mgrMonthlyTarget.target_activity}</p>
                </div>
                <div className="bg-white/10 rounded-2xl p-2.5">
                  <p className="text-[10px] text-indigo-200">New PD Target</p>
                  <p className="text-sm font-black text-amber-400">{mgrMonthlyTarget.target_new_pd}</p>
                </div>
              </div>
            )}
          </div>

          {/* Manager Today's Report & Daily Target Form */}
          <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-100">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-500" />
                Manager's Daily Report
              </h2>
              <div className="flex bg-slate-100 p-0.5 rounded-xl text-[11px] font-bold">
                <button
                  type="button"
                  onClick={() => setMyEntryMode('actual')}
                  className={`px-3 py-1 rounded-lg transition-all ${
                    myEntryMode === 'actual' ? 'bg-white text-indigo-700 shadow-sm' : 'text-slate-500'
                  }`}
                >
                  Actuals
                </button>
                <button
                  type="button"
                  onClick={() => setMyEntryMode('target')}
                  className={`px-3 py-1 rounded-lg transition-all ${
                    myEntryMode === 'target' ? 'bg-white text-indigo-700 shadow-sm' : 'text-slate-500'
                  }`}
                >
                  Daily Target
                </button>
              </div>
            </div>

            {myEntryMode === 'actual' ? (
              <div className="space-y-3.5">
                <div>
                  <label className="text-xs font-semibold text-slate-700 mb-1 block">Day Sales Amount (₹)</label>
                  <div className="relative">
                    <IndianRupee className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-500" />
                    <input
                      type="number"
                      value={mySales}
                      onChange={e => setMySales(e.target.value)}
                      placeholder="0"
                      className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-base font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 mb-1 block">Collection Amount (₹)</label>
                  <div className="relative">
                    <IndianRupee className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-blue-500" />
                    <input
                      type="number"
                      value={myCollection}
                      onChange={e => setMyCollection(e.target.value)}
                      placeholder="0"
                      className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-base font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 mb-1 block">Farmer's Visit/Meating</label>
                    <div className="relative">
                      <Activity className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-purple-500" />
                      <input
                        type="number"
                        value={myActivity}
                        onChange={e => setMyActivity(e.target.value)}
                        placeholder="0"
                        className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-base font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-700 mb-1 block">New PD (Count)</label>
                    <div className="relative">
                      <Briefcase className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-amber-500" />
                      <input
                        type="number"
                        value={myNewPd}
                        onChange={e => setMyNewPd(e.target.value)}
                        placeholder="0"
                        className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-base font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 mb-1 block">Notes / Remarks</label>
                  <textarea
                    value={myNotes}
                    onChange={e => setMyNotes(e.target.value)}
                    placeholder="Manager remarks, reviews, summary..."
                    rows={2}
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-2xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
                  />
                </div>
              </div>
            ) : (
              <div className="space-y-3.5 bg-indigo-50/50 p-3.5 rounded-2xl border border-indigo-100">
                <p className="text-xs font-bold text-indigo-900 flex items-center gap-1 mb-1">
                  <Target className="w-3.5 h-3.5 text-indigo-600" /> Set Manager's Daily Target
                </p>

                <div>
                  <label className="text-xs font-semibold text-slate-700 mb-1 block">Daily Sales Target (₹)</label>
                  <input
                    type="number"
                    value={myTargetSales}
                    onChange={e => setMyTargetSales(e.target.value)}
                    placeholder="e.g. 15000"
                    className="w-full px-3.5 py-2.5 bg-white border border-slate-200 rounded-2xl text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 mb-1 block">Daily Collection Target (₹)</label>
                  <input
                    type="number"
                    value={myTargetCollection}
                    onChange={e => setMyTargetCollection(e.target.value)}
                    placeholder="e.g. 10000"
                    className="w-full px-3.5 py-2.5 bg-white border border-slate-200 rounded-2xl text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 mb-1 block">Farmer's Visit/Meating Target</label>
                    <input
                      type="number"
                      value={myTargetActivity}
                      onChange={e => setMyTargetActivity(e.target.value)}
                      placeholder="e.g. 10"
                      className="w-full px-3.5 py-2.5 bg-white border border-slate-200 rounded-2xl text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 mb-1 block">New PD Target</label>
                    <input
                      type="number"
                      value={myTargetNewPd}
                      onChange={e => setMyTargetNewPd(e.target.value)}
                      placeholder="e.g. 3"
                      className="w-full px-3.5 py-2.5 bg-white border border-slate-200 rounded-2xl text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                </div>
              </div>
            )}

            <button
              onClick={handleSaveMyEntry}
              disabled={mySaving}
              className={`w-full mt-4 py-3.5 rounded-2xl font-bold text-white text-sm flex items-center justify-center gap-2 transition-all active:scale-[0.98] ${
                mySaved
                  ? 'bg-emerald-600'
                  : 'bg-gradient-to-r from-indigo-600 to-blue-600 shadow-lg shadow-indigo-500/25'
              }`}
            >
              {mySaving ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : mySaved ? (
                <><CheckCircle2 className="w-4 h-4" /> Saved Successfully!</>
              ) : (
                <><Save className="w-4 h-4" /> Save Manager's Report</>
              )}
            </button>
          </div>
        </div>
      )}


      {/* ==================== FULL TEAMMATE MONTH REPORT MODAL ==================== */}
      {historyModalMember && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-3xl shadow-2xl p-5 max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-base font-bold text-slate-900">{historyModalMember.name}'s Ledger</h3>
                <p className="text-[11px] text-slate-400">Full Monthly Report ({monthStr})</p>
              </div>
              <button
                onClick={() => setHistoryModalMember(null)}
                className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:text-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Monthly Target for this Teammate */}
            {memberHistoryMonthlyTarget && (
              <div className="my-3 bg-indigo-50 border border-indigo-200 rounded-2xl p-3">
                <p className="text-[10px] font-bold text-indigo-900 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                  <Target className="w-3.5 h-3.5 text-indigo-600" /> Locked Monthly Target
                </p>
                <div className="grid grid-cols-4 gap-1 text-center text-xs font-bold">
                  <div className="bg-white p-1 rounded-lg">
                    <p className="text-[10px] text-emerald-700">{formatCurrency(memberHistoryMonthlyTarget.target_sales)}</p>
                    <p className="text-[7px] text-slate-400">Sales</p>
                  </div>
                  <div className="bg-white p-1 rounded-lg">
                    <p className="text-[10px] text-blue-700">{formatCurrency(memberHistoryMonthlyTarget.target_collection)}</p>
                    <p className="text-[7px] text-slate-400">Collection</p>
                  </div>
                  <div className="bg-white p-1 rounded-lg">
                    <p className="text-[10px] text-purple-700">{memberHistoryMonthlyTarget.target_activity}</p>
                    <p className="text-[7px] text-slate-400">Farmer's Visit/Meating</p>
                  </div>
                  <div className="bg-white p-1 rounded-lg">
                    <p className="text-[10px] text-amber-700">{memberHistoryMonthlyTarget.target_new_pd}</p>
                    <p className="text-[7px] text-slate-400">New PD</p>
                  </div>
                </div>
              </div>
            )}

            <div className="flex-1 overflow-y-auto py-2 space-y-2.5">
              {loadingHistory ? (
                <div className="py-12 text-center">
                  <Loader2 className="w-6 h-6 animate-spin text-indigo-600 mx-auto mb-2" />
                  <p className="text-xs text-slate-400">Loading ledger records...</p>
                </div>
              ) : memberHistoryEntries.length === 0 ? (
                <div className="py-12 text-center">
                  <FileText className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="text-xs text-slate-400 font-medium">No daily records submitted by this member this month</p>
                </div>
              ) : (
                memberHistoryEntries.map((entry) => (
                  <div key={entry.entry_date} className="bg-slate-50 rounded-2xl p-3 border border-slate-100">
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-xs font-bold text-slate-800">
                        {new Date(entry.entry_date + 'T00:00:00').toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' })}
                      </span>
                      <span className="text-[10px] text-slate-400">
                        {entry.updated_at ? new Date(entry.updated_at).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : ''}
                      </span>
                    </div>
                    <div className="grid grid-cols-4 gap-1 text-center mb-1.5">
                      <div className="bg-white rounded-xl p-1 border border-emerald-100">
                        <p className="text-[10px] font-bold text-emerald-700">{formatCurrency(entry.sales_amount)}</p>
                        <p className="text-[7px] text-emerald-600">Sales</p>
                      </div>
                      <div className="bg-white rounded-xl p-1 border border-blue-100">
                        <p className="text-[10px] font-bold text-blue-700">{formatCurrency(entry.collection_amount)}</p>
                        <p className="text-[7px] text-blue-600">Collection</p>
                      </div>
                      <div className="bg-white rounded-xl p-1 border border-purple-100">
                        <p className="text-[10px] font-bold text-purple-700">{entry.activity_count}</p>
                        <p className="text-[7px] text-purple-600">FV</p>
                      </div>
                      <div className="bg-white rounded-xl p-1 border border-amber-100">
                        <p className="text-[10px] font-bold text-amber-700">{entry.new_pd_count}</p>
                        <p className="text-[7px] text-amber-600">New PD</p>
                      </div>
                    </div>
                    {entry.notes && (
                      <p className="text-[10px] text-slate-600 bg-white p-1.5 rounded-lg border border-slate-200/60 mt-1">
                        📝 {entry.notes}
                      </p>
                    )}
                  </div>
                ))
              )}
            </div>

            <button
              onClick={() => setHistoryModalMember(null)}
              className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-2xl text-xs transition-colors mt-2"
            >
              Close Ledger
            </button>
          </div>
        </div>
      )}

      {/* ==================== MANAGER SET MONTHLY TARGET MODAL ==================== */}
      {showManagerMonthlyModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-3xl shadow-2xl p-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Target className="w-5 h-5 text-indigo-600" />
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Set Manager Monthly Target</h3>
                  <p className="text-[10px] text-slate-400">{monthStr} (Lockable 1st - 7th)</p>
                </div>
              </div>
              <button
                onClick={() => setShowManagerMonthlyModal(false)}
                className="w-7 h-7 rounded-full bg-slate-100 text-slate-500 flex items-center justify-center"
              >
                ✕
              </button>
            </div>

            <p className="text-[11px] text-amber-700 bg-amber-50 border border-amber-200 rounded-xl p-2.5 my-3 leading-snug">
              ⚠️ Monthly target can only be set <strong>once per month between 1st and 7th</strong>. Once set, it is locked.
            </p>

            {mgrMonthlyTargetError && (
              <div className="p-2.5 mb-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 font-medium">
                {mgrMonthlyTargetError}
              </div>
            )}

            <div className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-700 mb-1 block">Monthly Sales Target (₹)</label>
                <input
                  type="number"
                  value={mMgrSales}
                  onChange={e => setMMgrSales(e.target.value)}
                  placeholder="e.g. 300000"
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 mb-1 block">Monthly Collection Target (₹)</label>
                <input
                  type="number"
                  value={mMgrCollection}
                  onChange={e => setMMgrCollection(e.target.value)}
                  placeholder="e.g. 200000"
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="text-xs font-semibold text-slate-700 mb-1 block">Farmer's Visit/Meating Target</label>
                  <input
                    type="number"
                    value={mMgrActivity}
                    onChange={e => setMMgrActivity(e.target.value)}
                    placeholder="e.g. 200"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700 mb-1 block">New PD Target</label>
                  <input
                    type="number"
                    value={mMgrNewPd}
                    onChange={e => setMMgrNewPd(e.target.value)}
                    placeholder="e.g. 50"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>
            </div>

            <div className="flex gap-2 mt-4 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setShowManagerMonthlyModal(false)}
                className="flex-1 py-2.5 bg-slate-100 text-slate-700 font-bold rounded-xl text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveManagerMonthlyTarget}
                disabled={savingMgrMonthlyTarget}
                className="flex-1 py-2.5 bg-indigo-600 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1 shadow-md active:scale-95 disabled:opacity-50"
              >
                {savingMgrMonthlyTarget ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                Confirm &amp; Lock
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
