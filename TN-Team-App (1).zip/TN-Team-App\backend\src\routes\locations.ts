import { Router, Request, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { dbGet, dbRun, dbAll } from '../database';
import { authenticate } from '../middleware/auth';

const router = Router();
router.use(authenticate);

// POST /api/locations
router.post('/', (req: Request, res: Response) => {
  const { userId, teamId } = req.user!;
  const { lat, lng, accuracy, speed, heading, altitude, tripId, isTracking } = req.body;

  if (lat === undefined || lng === undefined) {
    res.status(400).json({ error: 'lat and lng are required' });
    return;
  }

  if (tripId) {
    const trip = dbGet(
      `SELECT id FROM trips WHERE id = ? AND user_id = ? AND team_id = ?`,
      [tripId, userId, teamId]
    );
    if (!trip) { res.status(403).json({ error: 'Trip not found or not owned by you' }); return; }
  }

  const id = uuidv4();
  dbRun(
    `INSERT INTO locations (id, user_id, trip_id, team_id, lat, lng, accuracy, speed, heading, altitude, is_tracking, timestamp)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))`,
    [id, userId, tripId ?? null, teamId, lat, lng, accuracy ?? null, speed ?? null, heading ?? null, altitude ?? null, isTracking ? 1 : 0]
  );

  res.status(201).json({ id });
});

// GET /api/locations/current
router.get('/current', (req: Request, res: Response) => {
  const { userId, teamId } = req.user!;
  const location = dbGet(
    `SELECT id, lat, lng, accuracy, speed, heading, timestamp
     FROM locations WHERE user_id = ? AND team_id = ? ORDER BY timestamp DESC LIMIT 1`,
    [userId, teamId]
  );
  if (!location) { res.status(404).json({ error: 'No location data found' }); return; }
  res.json(location);
});

// GET /api/locations/history?limit=50
router.get('/history', (req: Request, res: Response) => {
  const { userId, teamId } = req.user!;
  const limit = Math.min(parseInt(req.query.limit as string || '50', 10), 200);
  const locations = dbAll(
    `SELECT id, lat, lng, accuracy, speed, heading, timestamp
     FROM locations WHERE user_id = ? AND team_id = ? ORDER BY timestamp DESC LIMIT ?`,
    [userId, teamId, limit]
  );
  res.json(locations);
});

// DELETE /api/locations
router.delete('/', (req: Request, res: Response) => {
  const { userId, teamId } = req.user!;
  dbRun(`DELETE FROM locations WHERE user_id = ? AND team_id = ?`, [userId, teamId]);
  res.json({ success: true });
});

export { router as locationsRouter };
