import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { api } from '../api';
import { Avatar } from '../components/Avatar';
import {
  Shield,
  MapPin,
  Trash2,
  LogOut,
  Lock,
  Eye,
  Download,
  Smartphone,
  CheckCircle2,
  KeyRound,
  Copy,
  Check,
  Edit2,
} from 'lucide-react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

export function SettingsScreen() {
  const { user, token, logout } = useAuth();
  const [deletingLocations, setDeletingLocations] = useState(false);
  const [confirmDeleteLocations, setConfirmDeleteLocations] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const [error, setError] = useState('');
  const [installPrompt, setInstallPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [installed, setInstalled] = useState(false);

  // Manager team password states
  const [teamPassword, setTeamPassword] = useState(user?.teamJoinPassword || '');
  const [isEditingPw, setIsEditingPw] = useState(false);
  const [newTeamPw, setNewTeamPw] = useState('');
  const [copied, setCopied] = useState(false);
  const [savingPw, setSavingPw] = useState(false);

  useEffect(() => {
    if (token && user?.role === 'manager') {
      api.manager.teamInfo(token)
        .then(info => {
          setTeamPassword(info.join_password);
        })
        .catch(console.error);
    }
  }, [token, user]);

  useEffect(() => {
    const handleBeforeInstall = (e: Event) => {
      e.preventDefault();
      setInstallPrompt(e as BeforeInstallPromptEvent);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    window.addEventListener('appinstalled', () => {
      setInstalled(true);
      setInstallPrompt(null);
    });

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
    };
  }, []);

  const handleInstallPwa = async () => {
    if (!installPrompt) return;
    await installPrompt.prompt();
    const choice = await installPrompt.userChoice;
    if (choice.outcome === 'accepted') {
      setInstalled(true);
    }
    setInstallPrompt(null);
  };

  const handleCopyPassword = () => {
    if (teamPassword) {
      navigator.clipboard.writeText(teamPassword);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleSaveTeamPassword = async () => {
    if (!token || !newTeamPw.trim()) return;
    setSavingPw(true);
    setError('');
    try {
      await api.manager.updateTeamPassword(token, newTeamPw.trim());
      setTeamPassword(newTeamPw.trim());
      setIsEditingPw(false);
      setSuccessMsg('Team Join Password updated successfully!');
      setTimeout(() => setSuccessMsg(''), 3000);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to update team password');
    } finally {
      setSavingPw(false);
    }
  };

  const handleDeleteLocationHistory = async () => {
    if (!token) return;
    setDeletingLocations(true);
    setError('');
    try {
      await api.locations.deleteAll(token);
      setSuccessMsg('Location history deleted successfully.');
      setConfirmDeleteLocations(false);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to delete location history');
    } finally {
      setDeletingLocations(false);
    }
  };

  if (!user) return null;

  return (
    <div className="h-full overflow-y-auto bg-slate-50">
      {/* Header */}
      <div className="bg-white px-4 pt-12 pb-6 border-b border-slate-100">
        <h1 className="text-xl font-bold text-slate-900 mb-4">Settings &amp; App</h1>
        <div className="flex items-center gap-4">
          <Avatar name={user.name} color={user.avatarColor} size="lg" />
          <div>
            <p className="text-base font-bold text-slate-900">{user.name}</p>
            <p className="text-sm text-slate-500">{user.email}</p>
            <span className={`inline-flex items-center gap-1 text-xs font-semibold mt-1 px-2.5 py-0.5 rounded-full ${
              user.role === 'manager' ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'
            }`}>
              {user.role === 'manager' ? '👔 Team Manager' : '🧑 Teammate'}
            </span>
          </div>
        </div>
      </div>

      {successMsg && (
        <div className="mx-4 mt-4 p-3 bg-green-50 border border-green-200 rounded-2xl">
          <p className="text-sm text-green-700 font-medium">{successMsg}</p>
        </div>
      )}
      {error && (
        <div className="mx-4 mt-4 p-3 bg-red-50 border border-red-200 rounded-2xl">
          <p className="text-sm text-red-700 font-medium">{error}</p>
        </div>
      )}

      {/* MANAGER: TEAM JOIN PASSWORD CARD */}
      {user.role === 'manager' && (
        <div className="mx-4 mt-6">
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-2">
            Team Join Password
          </p>
          <div className="bg-gradient-to-br from-purple-900 to-indigo-950 text-white rounded-3xl p-5 shadow-xl relative overflow-hidden">
            <div className="relative z-10">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <KeyRound className="w-4 h-4 text-purple-300" />
                  <span className="text-xs font-bold text-purple-200 uppercase tracking-wider">Team Join Passcode</span>
                </div>
                {!isEditingPw && (
                  <button
                    onClick={() => { setIsEditingPw(true); setNewTeamPw(teamPassword); }}
                    className="text-xs text-purple-300 hover:text-white flex items-center gap-1 font-semibold"
                  >
                    <Edit2 className="w-3.5 h-3.5" /> Edit
                  </button>
                )}
              </div>

              {!isEditingPw ? (
                <div>
                  <div className="flex items-center justify-between bg-white/10 backdrop-blur-md rounded-2xl px-4 py-3 border border-white/15 my-2">
                    <span className="text-xl font-mono font-bold tracking-widest text-white">
                      {teamPassword || '••••••'}
                    </span>
                    <button
                      onClick={handleCopyPassword}
                      className="px-3 py-1.5 bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors"
                    >
                      {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      {copied ? 'Copied!' : 'Copy Code'}
                    </button>
                  </div>
                  <p className="text-[11px] text-purple-200/80 leading-relaxed mt-2">
                    Share this unique password with your teammates. They will enter it when registering to join <strong>{user.teamName}</strong>.
                  </p>
                </div>
              ) : (
                <div className="space-y-3 mt-3">
                  <input
                    type="text"
                    value={newTeamPw}
                    onChange={e => setNewTeamPw(e.target.value)}
                    placeholder="Enter new team password"
                    className="w-full px-4 py-2.5 bg-white text-slate-900 rounded-xl text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-purple-400"
                  />
                  <div className="flex gap-2">
                    <button
                      onClick={() => setIsEditingPw(false)}
                      className="flex-1 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-bold transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleSaveTeamPassword}
                      disabled={savingPw}
                      className="flex-1 py-2 bg-purple-500 hover:bg-purple-600 text-white rounded-xl text-xs font-bold transition-colors"
                    >
                      {savingPw ? 'Saving...' : 'Save New Password'}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Team info */}
      <div className="mx-4 mt-6">
        <p className="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-2">Team Details</p>
        <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
          <SettingsRow icon={<Shield className="w-4 h-4 text-blue-500" />} label="Team Name" value={user.teamName} />
          <SettingsRow icon={<Lock className="w-4 h-4 text-slate-400" />} label="Your Role" value={user.role === 'manager' ? 'Manager' : 'Teammate'} />
        </div>
      </div>

      {/* DOWNLOAD / INSTALL SECTION */}
      <div className="mx-4 mt-6">
        <p className="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-2">
          Install &amp; Download App
        </p>
        <div className="bg-white rounded-2xl shadow-sm overflow-hidden p-4 space-y-4">
          {/* Direct ZIP Download */}
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center shrink-0">
              <Download className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-slate-900">Download Source Code (.ZIP)</p>
              <p className="text-xs text-slate-500 mt-0.5">
                Complete standalone backend &amp; frontend project ready to run anywhere.
              </p>
              <a
                href="/api/download/zip"
                download="tn-team-gps-app.zip"
                className="inline-flex items-center gap-1.5 mt-2.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white rounded-xl text-xs font-semibold shadow-sm transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                Download App ZIP (1.3 MB)
              </a>
            </div>
          </div>

          <div className="border-t border-slate-100 pt-3">
            {/* PWA Phone Installation */}
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-purple-50 text-purple-600 rounded-xl flex items-center justify-center shrink-0">
                <Smartphone className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-slate-900">Install on Mobile Device</p>
                <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">
                  Run as a standalone native app on your phone with an app icon and fullscreen experience:
                </p>

                {installed ? (
                  <div className="flex items-center gap-1.5 mt-2 text-xs font-semibold text-green-600 bg-green-50 px-3 py-1.5 rounded-xl">
                    <CheckCircle2 className="w-4 h-4" /> App already installed!
                  </div>
                ) : installPrompt ? (
                  <button
                    onClick={handleInstallPwa}
                    className="inline-flex items-center gap-1.5 mt-2.5 px-4 py-2 bg-purple-600 hover:bg-purple-700 active:bg-purple-800 text-white rounded-xl text-xs font-semibold shadow-sm transition-colors"
                  >
                    <Smartphone className="w-3.5 h-3.5" />
                    Install App on this Device
                  </button>
                ) : (
                  <div className="mt-2 text-xs text-slate-600 bg-slate-50 p-2.5 rounded-xl space-y-1">
                    <p>• <strong>iPhone / iPad (Safari)</strong>: Tap <em>Share</em> icon → <em>Add to Home Screen</em>.</p>
                    <p>• <strong>Android (Chrome)</strong>: Tap <em>Three dots (⋮)</em> → <em>Install app</em> or <em>Add to Home Screen</em>.</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Privacy */}
      <div className="mx-4 mt-6">
        <p className="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-2">Privacy &amp; Data</p>
        <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
          <div className="p-4 border-b border-slate-100">
            <div className="flex items-start gap-3">
              <Eye className="w-4 h-4 text-slate-400 mt-0.5 shrink-0" />
              <div>
                <p className="text-sm font-semibold text-slate-900">Who can see my location?</p>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  {user.role === 'manager'
                    ? 'As a manager, you can see all members of your team. Other teams cannot see your location.'
                    : 'Only your manager can see your location and trip history. Other teammates cannot see your location. Location is only recorded while tracking is active.'}
                </p>
              </div>
            </div>
          </div>
          <div className="p-4 border-b border-slate-100">
            <div className="flex items-start gap-3">
              <MapPin className="w-4 h-4 text-slate-400 mt-0.5 shrink-0" />
              <div>
                <p className="text-sm font-semibold text-slate-900">Location tracking</p>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  Your location is only recorded when you explicitly start a trip. Background tracking is active only during an active trip session.
                </p>
              </div>
            </div>
          </div>
          <div className="p-4">
            {!confirmDeleteLocations ? (
              <button
                onClick={() => setConfirmDeleteLocations(true)}
                className="flex items-center gap-3 w-full text-left"
              >
                <Trash2 className="w-4 h-4 text-red-500 shrink-0" />
                <div>
                  <p className="text-sm font-semibold text-red-600">Delete location history</p>
                  <p className="text-xs text-slate-400 mt-0.5">Remove all your stored location data</p>
                </div>
              </button>
            ) : (
              <div>
                <p className="text-sm font-semibold text-red-800 mb-1">Delete all location history?</p>
                <p className="text-xs text-slate-500 mb-3">This will permanently delete all your stored location pings. Trip records will be kept.</p>
                <div className="flex gap-2">
                  <button
                    onClick={() => setConfirmDeleteLocations(false)}
                    className="flex-1 py-2 bg-slate-100 text-slate-700 rounded-xl text-sm font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleDeleteLocationHistory}
                    disabled={deletingLocations}
                    className="flex-1 py-2 bg-red-600 text-white rounded-xl text-sm font-semibold"
                  >
                    {deletingLocations ? 'Deleting...' : 'Delete'}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Sign out */}
      <div className="mx-4 mt-6 mb-28">
        <button
          onClick={logout}
          className="w-full flex items-center justify-center gap-2 py-3.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-2xl font-semibold text-sm transition-colors"
        >
          <LogOut className="w-4 h-4" />
          Sign Out
        </button>
      </div>
    </div>
  );
}

function SettingsRow({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="flex items-center gap-3 px-4 py-3.5 border-b border-slate-100 last:border-0">
      <div className="shrink-0">{icon}</div>
      <p className="text-sm text-slate-700 flex-1">{label}</p>
      <p className="text-sm text-slate-500 font-medium">{value}</p>
    </div>
  );
}
