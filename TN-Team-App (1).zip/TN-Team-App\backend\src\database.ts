import initSqlJs, { Database as SqlJsDb } from 'sql.js';
import path from 'path';
import fs from 'fs';
import { config } from './config';

let db: SqlJsDb;
let SQL: Awaited<ReturnType<typeof initSqlJs>>;
let saveTimer: NodeJS.Timeout | null = null;
let backupInterval: NodeJS.Timeout | null = null;

export async function initDb(): Promise<void> {
  SQL = await initSqlJs();
  const dbDir = path.dirname(config.dbPath);
  if (!fs.existsSync(dbDir)) {
    fs.mkdirSync(dbDir, { recursive: true });
  }

  const backupDir = path.join(dbDir, 'backups');
  if (!fs.existsSync(backupDir)) {
    fs.mkdirSync(backupDir, { recursive: true });
  }

  if (fs.existsSync(config.dbPath)) {
    const fileBuffer = fs.readFileSync(config.dbPath);
    db = new SQL.Database(fileBuffer);
    console.log(`📦 Loaded existing database (${fileBuffer.length} bytes) from ${config.dbPath}`);
    // Create startup snapshot
    backupDb('startup');
  } else {
    db = new SQL.Database();
    console.log('🆕 Initialized fresh in-memory database');
  }

  initSchema();
  scheduleSave();

  // Periodic rolling backup every 4 hours
  if (!backupInterval) {
    backupInterval = setInterval(() => backupDb('auto'), 4 * 60 * 60 * 1000);
  }
}

/** Save db to disk with atomic write */
function scheduleSave() {
  if (saveTimer) return;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    persistDb();
    scheduleSave();
  }, 2000);
}

/** Atomic disk flush to prevent database corruption during sudden power outage / crash */
export function persistDb(): void {
  if (!db) return;
  try {
    const data = db.export();
    const buffer = Buffer.from(data);
    const tmpPath = `${config.dbPath}.tmp`;
    fs.writeFileSync(tmpPath, buffer);
    fs.renameSync(tmpPath, config.dbPath);
  } catch (e) {
    console.error('Failed to persist DB:', e);
  }
}

/** Create a timestamped backup copy in data/backups/ */
export function backupDb(tag = 'manual'): string | null {
  if (!db) return null;
  try {
    persistDb();
    const dbDir = path.dirname(config.dbPath);
    const backupDir = path.join(dbDir, 'backups');
    if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });

    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const backupFile = path.join(backupDir, `tracker-${tag}-${timestamp}.db`);
    const data = db.export();
    fs.writeFileSync(backupFile, Buffer.from(data));

    // Keep only last 10 backups to manage disk space
    const files = fs.readdirSync(backupDir)
      .filter(f => f.endsWith('.db'))
      .map(f => ({ name: f, path: path.join(backupDir, f), time: fs.statSync(path.join(backupDir, f)).mtime.getTime() }))
      .sort((a, b) => b.time - a.time);

    if (files.length > 10) {
      files.slice(10).forEach(f => {
        try { fs.unlinkSync(f.path); } catch {}
      });
    }

    console.log(`💾 Database snapshot saved: ${backupFile}`);
    return backupFile;
  } catch (e) {
    console.error('Failed to create DB backup:', e);
    return null;
  }
}

export function getDb(): SqlJsDb {
  if (!db) throw new Error('Database not initialized. Call initDb() first.');
  return db;
}

/** Save immediately (call on shutdown) */
export function closeDb(): void {
  if (saveTimer) clearTimeout(saveTimer);
  if (backupInterval) clearInterval(backupInterval);
  persistDb();
  if (db) db.close();
  console.log('🛑 Database cleanly closed and saved to disk');
}

export type QueryParam = string | number | null | undefined | boolean;

function normalizeParams(params: QueryParam[]): (string | number | null)[] {
  return params.map(p => {
    if (p === undefined || p === null) return null;
    if (typeof p === 'boolean') return p ? 1 : 0;
    return p;
  });
}

/** Execute a query and return all rows as objects */
export function dbAll<T = Record<string, unknown>>(sql: string, params: QueryParam[] = []): T[] {
  const stmt = db.prepare(sql);
  stmt.bind(normalizeParams(params));
  const rows: T[] = [];
  while (stmt.step()) {
    rows.push(stmt.getAsObject() as T);
  }
  stmt.free();
  return rows;
}

/** Execute a query and return one row */
export function dbGet<T = Record<string, unknown>>(sql: string, params: QueryParam[] = []): T | undefined {
  const rows = dbAll<T>(sql, params);
  return rows[0];
}

/** Execute a write statement */
export function dbRun(sql: string, params: QueryParam[] = []): void {
  db.run(sql, normalizeParams(params));
}

/** Execute multiple statements (no params) */
export function dbExec(sql: string): void {
  db.run(sql);
}

function initSchema(): void {
  db.run(`
    CREATE TABLE IF NOT EXISTS teams (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      join_password TEXT NOT NULL DEFAULT '123456',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      team_id TEXT NOT NULL REFERENCES teams(id),
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL CHECK(role IN ('manager','member')),
      avatar_color TEXT NOT NULL DEFAULT '#6366f1',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE INDEX IF NOT EXISTS idx_users_team ON users(team_id);
    CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

    CREATE TABLE IF NOT EXISTS trips (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id),
      team_id TEXT NOT NULL REFERENCES teams(id),
      status TEXT NOT NULL DEFAULT 'active',
      distance_m REAL NOT NULL DEFAULT 0,
      duration_s INTEGER NOT NULL DEFAULT 0,
      start_address TEXT,
      end_address TEXT,
      start_lat REAL,
      start_lng REAL,
      end_lat REAL,
      end_lng REAL,
      started_at TEXT NOT NULL DEFAULT (datetime('now')),
      ended_at TEXT,
      paused_at TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE INDEX IF NOT EXISTS idx_trips_user ON trips(user_id);
    CREATE INDEX IF NOT EXISTS idx_trips_team ON trips(team_id);
    CREATE INDEX IF NOT EXISTS idx_trips_started ON trips(started_at);

    CREATE TABLE IF NOT EXISTS locations (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id),
      trip_id TEXT REFERENCES trips(id),
      team_id TEXT NOT NULL REFERENCES teams(id),
      lat REAL NOT NULL,
      lng REAL NOT NULL,
      accuracy REAL,
      speed REAL,
      heading REAL,
      altitude REAL,
      is_tracking INTEGER NOT NULL DEFAULT 0,
      timestamp TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE INDEX IF NOT EXISTS idx_locations_user ON locations(user_id);
    CREATE INDEX IF NOT EXISTS idx_locations_trip ON locations(trip_id);
    CREATE INDEX IF NOT EXISTS idx_locations_timestamp ON locations(timestamp);

    CREATE TABLE IF NOT EXISTS daily_entries (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id),
      team_id TEXT NOT NULL REFERENCES teams(id),
      entry_date TEXT NOT NULL,
      sales_amount REAL NOT NULL DEFAULT 0,
      collection_amount REAL NOT NULL DEFAULT 0,
      activity_count INTEGER NOT NULL DEFAULT 0,
      new_pd_count INTEGER NOT NULL DEFAULT 0,
      target_sales REAL NOT NULL DEFAULT 0,
      target_collection REAL NOT NULL DEFAULT 0,
      target_activity INTEGER NOT NULL DEFAULT 0,
      target_new_pd INTEGER NOT NULL DEFAULT 0,
      notes TEXT DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE(user_id, entry_date)
    );

    CREATE INDEX IF NOT EXISTS idx_daily_user ON daily_entries(user_id);
    CREATE INDEX IF NOT EXISTS idx_daily_date ON daily_entries(entry_date);
    CREATE INDEX IF NOT EXISTS idx_daily_team ON daily_entries(team_id);

    CREATE TABLE IF NOT EXISTS monthly_targets (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id),
      team_id TEXT NOT NULL REFERENCES teams(id),
      target_month TEXT NOT NULL,
      target_sales REAL NOT NULL DEFAULT 0,
      target_collection REAL NOT NULL DEFAULT 0,
      target_activity INTEGER NOT NULL DEFAULT 0,
      target_new_pd INTEGER NOT NULL DEFAULT 0,
      is_locked INTEGER NOT NULL DEFAULT 1,
      set_at TEXT NOT NULL DEFAULT (datetime('now')),
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE(user_id, target_month)
    );

    CREATE INDEX IF NOT EXISTS idx_monthly_targets_user ON monthly_targets(user_id);
    CREATE INDEX IF NOT EXISTS idx_monthly_targets_month ON monthly_targets(target_month);

    CREATE TABLE IF NOT EXISTS manager_comments (
      id TEXT PRIMARY KEY,
      manager_id TEXT NOT NULL REFERENCES users(id),
      member_id TEXT NOT NULL REFERENCES users(id),
      team_id TEXT NOT NULL REFERENCES teams(id),
      sender_id TEXT REFERENCES users(id),
      sender_name TEXT,
      sender_role TEXT NOT NULL DEFAULT 'manager',
      comment TEXT NOT NULL,
      entry_date TEXT,
      is_read INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE INDEX IF NOT EXISTS idx_comments_member ON manager_comments(member_id);
    CREATE INDEX IF NOT EXISTS idx_comments_date ON manager_comments(created_at);

    CREATE TABLE IF NOT EXISTS notifications (
      id TEXT PRIMARY KEY,
      team_id TEXT NOT NULL REFERENCES teams(id),
      from_user_id TEXT NOT NULL REFERENCES users(id),
      from_user_name TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT 'daily_entry',
      summary TEXT NOT NULL,
      is_seen INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE INDEX IF NOT EXISTS idx_notifications_team ON notifications(team_id);
    CREATE INDEX IF NOT EXISTS idx_notifications_seen ON notifications(is_seen);
  `);

  // Safe migration: Add join_password column if missing
  try {
    db.run(`ALTER TABLE teams ADD COLUMN join_password TEXT NOT NULL DEFAULT '123456'`);
  } catch {
    // Column already exists
  }

  // Safe migrations for daily_entries
  try { db.run(`ALTER TABLE daily_entries ADD COLUMN new_pd_count INTEGER NOT NULL DEFAULT 0`); } catch {}
  try { db.run(`ALTER TABLE daily_entries ADD COLUMN target_sales REAL NOT NULL DEFAULT 0`); } catch {}
  try { db.run(`ALTER TABLE daily_entries ADD COLUMN target_collection REAL NOT NULL DEFAULT 0`); } catch {}
  try { db.run(`ALTER TABLE daily_entries ADD COLUMN target_activity INTEGER NOT NULL DEFAULT 0`); } catch {}
  try { db.run(`ALTER TABLE daily_entries ADD COLUMN target_new_pd INTEGER NOT NULL DEFAULT 0`); } catch {}
  try { db.run(`ALTER TABLE daily_entries ADD COLUMN target_submitted_at TEXT`); } catch {}

  // Safe migrations for manager_comments
  try { db.run(`ALTER TABLE manager_comments ADD COLUMN sender_id TEXT`); } catch {}
  try { db.run(`ALTER TABLE manager_comments ADD COLUMN sender_name TEXT`); } catch {}
  try { db.run(`ALTER TABLE manager_comments ADD COLUMN sender_role TEXT NOT NULL DEFAULT 'manager'`); } catch {}
  try { db.run(`ALTER TABLE manager_comments ADD COLUMN is_read INTEGER NOT NULL DEFAULT 0`); } catch {}
}
