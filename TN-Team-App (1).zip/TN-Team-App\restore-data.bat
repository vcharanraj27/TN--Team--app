@echo off
title TN Team - Database Restore Utility
color 0C
echo ===================================================
echo           TN TEAM - DATABASE RESTORE
echo ===================================================
echo.

cd /d "%~dp0"
if not exist "backend\data\backups" (
    echo [ERROR] No backups directory found at backend\data\backups
    pause
    exit /b 1
)

echo Available backup files:
echo ---------------------------------------------------
dir /b /o-d "backend\data\backups\*.db"
echo ---------------------------------------------------
echo.
set /p backupName="Enter exact backup filename to restore (e.g. tracker-startup-2026-10-03.db): "

if not exist "backend\data\backups\%backupName%" (
    echo [ERROR] Backup file backend\data\backups\%backupName% does not exist.
    pause
    exit /b 1
)

echo.
echo WARNING: This will overwrite backend\data\tracker.db with the selected backup.
set /p confirm="Are you sure you want to proceed? (y/n): "
if /i not "%confirm%"=="y" (
    echo Restoration cancelled.
    pause
    exit /b 0
)

copy /y "backend\data\backups\%backupName%" "backend\data\tracker.db" >nul
echo.
echo [SUCCESS] Database restored from %backupName%!
echo Restart the server to load the restored data.
echo.
pause
