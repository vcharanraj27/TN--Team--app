@echo off
title TN Team Platform - Production Server
color 0A
echo ===================================================
echo           TN TEAM - PRODUCTION RUNNER
echo ===================================================
echo.

cd /d "%~dp0"

echo [1/3] Checking Node.js environment...
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not installed or not in PATH.
    pause
    exit /b 1
)

echo [2/3] Verifying backend database storage...
if not exist "backend\data" (
    mkdir "backend\data"
)
if not exist "backend\data\backups" (
    mkdir "backend\data\backups"
)

echo [3/3] Starting TN Team Server on http://localhost:4000...
echo.
cd backend
npx ts-node src/index.ts
pause
